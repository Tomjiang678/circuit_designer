using System.ComponentModel;
using System.Drawing.Drawing2D;
using CircuitModuleDesigner.Modules.SignalConversion.Models;

namespace CircuitModuleDesigner.Modules.SignalConversion.Controls;

public sealed class SignalConversionTransferPlotControl : UserControl
{
    private readonly ComboBox gainSelector=new(){DropDownStyle=ComboBoxStyle.DropDownList,Width=130};
    private SignalConversionDesignResult? result;private IReadOnlyList<TransferRange> ranges=[];private bool updating;

    public SignalConversionTransferPlotControl()
    {
        Dock=DockStyle.Fill;DoubleBuffered=true;BackColor=Color.White;gainSelector.SelectedIndexChanged+=(_,_)=>{if(!updating)Invalidate();};Controls.Add(gainSelector);
    }

    [Browsable(false),DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public SignalConversionDesignResult? Result{get=>result;set{result=value;PopulateRanges();Invalidate();}}
    [Browsable(false)]public int AvailableGainCount=>ranges.Count;
    [Browsable(false)]public int DisplayedCurveCount=>result is null?0:1;
    [Browsable(false)]public string DisplayedFormula=>ranges.Count==0?string.Empty:Formula(ranges[Math.Clamp(gainSelector.SelectedIndex,0,ranges.Count-1)]);
    [Browsable(false)]public double DisplayedInputMinimum=>Selected().InputMinimum;
    [Browsable(false)]public double DisplayedInputMaximum=>Selected().InputMaximum;
    [Browsable(false),DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public int SelectedGainIndex{get=>Math.Max(0,gainSelector.SelectedIndex);set{if(value>=0&&value<gainSelector.Items.Count)gainSelector.SelectedIndex=value;}}

    protected override void OnLayout(LayoutEventArgs e){base.OnLayout(e);gainSelector.Location=new Point(Math.Max(8,ClientSize.Width-gainSelector.Width-18),12);}
    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);e.Graphics.SmoothingMode=SmoothingMode.AntiAlias;
        if(result is null||ranges.Count==0){TextRenderer.DrawText(e.Graphics,"Run an I/V design to view the transfer.",Font,ClientRectangle,Color.DimGray,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter);return;}
        var range=Selected();var left=104;var top=Math.Max(90,gainSelector.Bottom+44);var bottom=72;var right=34;
        var plot=new Rectangle(left,top,Math.Max(120,Width-left-right),Math.Max(100,Height-top-bottom));
        using var grid=new Pen(Color.FromArgb(228,232,237));using var axis=new Pen(Color.FromArgb(80,90,100),1.2f);
        for(var i=0;i<=5;i++){var x=plot.Left+i*plot.Width/5;var y=plot.Top+i*plot.Height/5;e.Graphics.DrawLine(grid,x,plot.Top,x,plot.Bottom);e.Graphics.DrawLine(grid,plot.Left,y,plot.Right,y);}
        e.Graphics.DrawRectangle(axis,plot);
        var outputMin=Math.Min(range.OutputMinimum,range.OutputMaximum);var outputMax=Math.Max(range.OutputMinimum,range.OutputMaximum);
        if(Math.Abs(outputMax-outputMin)<1e-30){outputMin-=1;outputMax+=1;}
        DrawCurves(e.Graphics,plot,range,outputMin,outputMax);DrawAxes(e.Graphics,plot,range,outputMin,outputMax);DrawHeader(e.Graphics,plot,range);
    }

    private static void DrawCurves(Graphics graphics,Rectangle plot,TransferRange range,double outputMin,double outputMax)
    {
        const int count=160;var actual=new PointF[count+1];var target=new PointF[count+1];
        for(var i=0;i<=count;i++)
        {
            var fraction=i/(double)count;var input=range.InputMinimum+(range.InputMaximum-range.InputMinimum)*fraction;
            actual[i]=new(plot.Left+(float)(fraction*plot.Width),MapY(plot,outputMin,outputMax,range.ActualOffset+range.ActualSlope*input));
            target[i]=new(plot.Left+(float)(fraction*plot.Width),MapY(plot,outputMin,outputMax,range.TargetOffset+range.TargetSlope*input));
        }
        using var targetPen=new Pen(Color.Gray,1.5f){DashStyle=DashStyle.Dash};using var actualPen=new Pen(Color.FromArgb(38,116,170),2.7f);
        graphics.DrawLines(targetPen,target);graphics.DrawLines(actualPen,actual);
    }

    private void DrawAxes(Graphics graphics,Rectangle plot,TransferRange range,double outputMin,double outputMax)
    {
        var flags=TextFormatFlags.NoPadding|TextFormatFlags.SingleLine|TextFormatFlags.VerticalCenter;
        TextRenderer.DrawText(graphics,Format(range.InputMinimum,"A"),Font,new Rectangle(plot.Left,plot.Bottom+6,plot.Width/2,24),Color.DimGray,flags|TextFormatFlags.Left);
        TextRenderer.DrawText(graphics,Format(range.InputMaximum,"A"),Font,new Rectangle(plot.Left+plot.Width/2,plot.Bottom+6,plot.Width/2,24),Color.DimGray,flags|TextFormatFlags.Right);
        TextRenderer.DrawText(graphics,Format(outputMin,"V"),Font,new Rectangle(4,plot.Bottom-12,plot.Left-14,24),Color.DimGray,flags|TextFormatFlags.Right);
        TextRenderer.DrawText(graphics,Format(outputMax,"V"),Font,new Rectangle(4,plot.Top-12,plot.Left-14,24),Color.DimGray,flags|TextFormatFlags.Right);
        using var bold=new Font(Font,FontStyle.Bold);
        TextRenderer.DrawText(graphics,"VOUT (V)",bold,new Rectangle(plot.Left+8,plot.Top+7,120,24),Color.FromArgb(45,50,58),Color.White,flags|TextFormatFlags.Left);
        TextRenderer.DrawText(graphics,"IIN (A)",bold,new Rectangle(plot.Right-128,plot.Bottom-31,120,24),Color.FromArgb(45,50,58),Color.White,flags|TextFormatFlags.Right);
    }

    private void DrawHeader(Graphics graphics,Rectangle plot,TransferRange range)
    {
        using var formulaFont=new Font(Font.FontFamily,10F,FontStyle.Bold);var width=gainSelector.Visible?Math.Max(120,plot.Width-gainSelector.Width-16):plot.Width;
        TextRenderer.DrawText(graphics,Formula(range),formulaFont,new Rectangle(plot.Left,8,width,30),Color.FromArgb(38,116,170),TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis);
        TextRenderer.DrawText(graphics,$"Range: {Format(range.InputMinimum,"A")} to {Format(range.InputMaximum,"A")}; output {Format(range.OutputMinimum,"V")} to {Format(range.OutputMaximum,"V")}",Font,
            new Rectangle(plot.Left,40,plot.Width,26),Color.FromArgb(75,80,88),TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter|TextFormatFlags.NoPadding);
    }

    private void PopulateRanges()
    {
        ranges=BuildRanges();updating=true;try{gainSelector.Items.Clear();foreach(var range in ranges)gainSelector.Items.Add(range.Name);gainSelector.SelectedIndex=ranges.Count==0?-1:0;gainSelector.Visible=ranges.Count>1;}finally{updating=false;}
    }

    private IReadOnlyList<TransferRange> BuildRanges()
    {
        if(result?.Recommended is not { } candidate)return [];
        if(candidate.Ranges.Count>0)return candidate.Ranges.Select(range=>new TransferRange(range.Name,range.InputMinimum,range.InputMaximum,
            range.OutputMinimum,range.OutputMaximum,range.TargetSlope,range.TargetOffset,range.ActualSlope,range.ActualOffset)).ToArray();
        var request=result.Request;return [new("Transfer",request.InputMinimum,request.InputMaximum,request.OutputAtInputMinimum,request.OutputAtInputMaximum,
            result.TransferSlope,result.TransferOffset,candidate.ActualTransferSlope,candidate.ActualTransferOffset)];
    }

    private TransferRange Selected()=>ranges.Count==0?new("",double.NaN,double.NaN,double.NaN,double.NaN,0,0,0,0):ranges[Math.Clamp(gainSelector.SelectedIndex,0,ranges.Count-1)];
    private string Formula(TransferRange range)=>$"{range.Name}: VOUT = {range.ActualOffset:G6} V {(range.ActualSlope<0?"-":"+")} IIN * {Format(Math.Abs(range.ActualSlope),"ohm")}  (target dashed)";
    private static float MapY(Rectangle plot,double min,double max,double value)=>plot.Bottom-(float)((value-min)/(max-min)*plot.Height);
    private static string Format(double value,string unit)
    {
        var magnitude=Math.Abs(value);if(magnitude<1e-15)return $"0 {unit}";
        var (scale,prefix)=magnitude switch{>=1e9=>(1e9,"G"),>=1e6=>(1e6,"M"),>=1e3=>(1e3,"k"),>=1=>(1d,""),>=1e-3=>(1e-3,"m"),>=1e-6=>(1e-6,"u"),>=1e-9=>(1e-9,"n"),>=1e-12=>(1e-12,"p"),_=>(1e-15,"f")};
        return $"{value/scale:G4} {prefix}{unit}";
    }
    private sealed record TransferRange(string Name,double InputMinimum,double InputMaximum,double OutputMinimum,double OutputMaximum,double TargetSlope,double TargetOffset,double ActualSlope,double ActualOffset);
}
