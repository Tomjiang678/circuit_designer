# I/V 500 点输入范围矩阵（拓扑适配数）

## 方法

- 500 个互不相同的输入电流范围（1E-12 … 1 A），覆盖正/负同号、双极性、过零、零基、对称和偏置形状。
- 固定工程假设：单电源 VEE=0 V / VCC=5 V，运放共模 0…5 V，目标精度 1%（默认按满量程结算；若在高级选项中显式给出最小有效电流，则按该电流结算），目标带宽 10000 Hz，E96，负载 1 MΩ，输入+传感器电容 50 pF，Burden ≤ 100 mV，Shunt 功耗 ≤ 0.5 W，其余为模块默认抽象运放参数。
- 每个范围用两种自然映射评估：反相满摆幅（VCC→VEE，TIA 家族）和非反相满摆幅（VEE→VCC，Shunt 家族）；同号范围再加零参考映射。
- 一个拓扑只要在任一映射下为 `FullyFeasible` 或 `ConditionallyFeasible` 就计为“合适”。因此计数回答的是“这个电流范围能不能被该拓扑实现”，而不是某一次固定端点映射的结果。

## 结果分布

| 合适拓扑数 | 范围数 |
| ---: | ---: |
| 0 | 229 |
| 1 | 24 |
| 2 | 106 |
| 3 | 100 |
| 4 | 33 |
| 5 | 8 |

- 至少 1 种拓扑可用：271 / 500（54.2%）。
- 完全没有可用拓扑：229 / 500（45.8%）。

## 常见映射检查

| 映射 | 合适数 | 合适拓扑 |
| --- | ---: | --- |
| 0…100 µA → 3.3…0 V（UI 默认） | 2 | Biased TIA, Programmable-Gain / Multi-Range TIA |
| 0…1 mA → 0…5 V | 2 | Low-Side Shunt + Op-Amp, High-Side Shunt + Op-Amp |
| 0…10 µA → 0…5 V | 2 | Low-Side Shunt + Op-Amp, High-Side Shunt + Op-Amp |
| 0…20 mA → 0…5 V | 2 | Low-Side Shunt + Op-Amp, High-Side Shunt + Op-Amp |
| 4…20 mA → 1…5 V | 2 | Low-Side Shunt + Op-Amp, High-Side Shunt + Op-Amp |
| 0…1 A → 0…5 V | 2 | Low-Side Shunt + Op-Amp, High-Side Shunt + Op-Amp |
| 1…10 mA → 0.5…5 V | 2 | Low-Side Shunt + Op-Amp, High-Side Shunt + Op-Amp |

## 各拓扑可用范围数

| 拓扑 | 可用范围数 | 占比 |
| --- | ---: | ---: |
| Basic TIA | 66 | 13.2% |
| Biased TIA | 186 | 37.2% |
| Programmable-Gain / Multi-Range TIA | 121 | 24.2% |
| Low-Side Shunt + Op-Amp | 148 | 29.6% |
| High-Side Shunt + Op-Amp | 187 | 37.4% |

## 主要阻塞原因（按首条约束归类）

| 阻塞类别 | 范围数 |
| --- | ---: |
| 带宽不足 | 189 |
| 运放输出电流不足 | 30 |
| 参考电压无法由供电轨生成 | 10 |

## 零可用范围按形状

| 形状 | 范围数 |
| --- | ---: |
| negative | 53 |
| bipolar-negative | 47 |
| positive | 43 |
| bipolar-positive | 43 |
| symmetric-small | 14 |
| zero-based | 10 |
| offset | 10 |
| symmetric | 9 |

## 零可用范围按峰值数量级

| 峰值区间 | 范围数 |
| --- | ---: |
| 1E-15 … 1E-14 A | 1 |
| 1E-14 … 1E-13 A | 2 |
| 1E-13 … 1E-12 A | 2 |
| 1E-12 … 1E-11 A | 38 |
| 1E-11 … 1E-10 A | 42 |
| 1E-10 … 1E-09 A | 40 |
| 1E-09 … 1E-08 A | 40 |
| 1E-08 … 1E-07 A | 34 |
| 0.01 … 0.1 A | 6 |
| 0.1 … 1 A | 15 |
| 1 … 10 A | 9 |

## 每个数量级一个可用样例

| 测试点 | 输入范围 | 合适数 | 合适拓扑 |
| --- | --- | ---: | --- |
| R060_bipolar-positive | -3.16227766E-09 … 3.16227766E-08 | 2 | Low-Side Shunt + Op-Amp, High-Side Shunt + Op-Amp |
| R286_bipolar-negative | -1E-07 … 1E-10 | 4 | Basic TIA, Biased TIA, Low-Side Shunt + Op-Amp, High-Side Shunt + Op-Amp |
| R385_bipolar-negative | -3.16227766E-06 … 3.16227766E-10 | 5 | Basic TIA, Biased TIA, Programmable-Gain / Multi-Range TIA, Low-Side Shunt + Op-Amp, High-Side Shunt + Op-Amp |
| R290_bipolar-negative | -1E-05 … 1E-08 | 5 | Basic TIA, Biased TIA, Programmable-Gain / Multi-Range TIA, Low-Side Shunt + Op-Amp, High-Side Shunt + Op-Amp |
| R292_bipolar-negative | -0.0001 … 1E-07 | 5 | Basic TIA, Biased TIA, Programmable-Gain / Multi-Range TIA, Low-Side Shunt + Op-Amp, High-Side Shunt + Op-Amp |
| R294_bipolar-negative | -0.001 … 1E-06 | 5 | Basic TIA, Biased TIA, Programmable-Gain / Multi-Range TIA, Low-Side Shunt + Op-Amp, High-Side Shunt + Op-Amp |
| R296_bipolar-negative | -0.01 … 1E-05 | 4 | Basic TIA, Biased TIA, Low-Side Shunt + Op-Amp, High-Side Shunt + Op-Amp |
| R023_positive | 0.01 … 0.1 | 2 | Low-Side Shunt + Op-Amp, High-Side Shunt + Op-Amp |
| R025_positive | 0.1 … 1 | 2 | Low-Side Shunt + Op-Amp, High-Side Shunt + Op-Amp |

## 读法

1. 计数为 0 只表示在**上述固定假设**下没有拓扑能同时满足极性、参考可生成、端点/误差预算、带宽和器件能力；不代表模块崩溃。
2. 误差预算默认按满量程电流结算（“目标精度 1%”= 满量程的 1%）。若在高级选项里显式给出最小有效电流，则改为按该电流结算，会严格得多。
3. 剩余 0 的主要来源是带宽：pA/nA 满量程需要极大的 Rf，与 10 kHz 带宽、55 pF 输入电容和 10 MHz GBW 物理冲突。降低带宽或改善器件参数即可进入可行区。
4. 正电流的 TIA 需要负斜率或负参考；单电源 0…5 V 下 1…10 mA → 0…5 V 这类带负截距的映射在五种拓扑里没有可实现的参考，计数为 0 是正确的（改成 0.5…5 V 即可）。
5. 每行的第一个阻塞原因在矩阵文件的 `Blocker` 列；逐拓扑结论在五列 `topology@mapping` 中。

## 文件

- `IV_500_INPUT_RANGE_TEST_POINTS.txt`：33 列批处理输入，可直接用 Batch Test 对话框加载（每行采用该范围最宽松的映射）。
- `IV_500_INPUT_RANGE_MATRIX.txt`：500 行完整矩阵（含每拓扑结论与阻塞原因）。
- `IV_500_INPUT_RANGE_SUMMARY.md`：本文件。
