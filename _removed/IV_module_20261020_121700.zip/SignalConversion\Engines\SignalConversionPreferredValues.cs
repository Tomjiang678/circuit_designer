using CircuitModuleDesigner.Modules.PrecisionAnalogComputing.Models;
using CircuitModuleDesigner.Modules.PrecisionAnalogComputing.Synthesis;
using CircuitModuleDesigner.Modules.SignalConversion.Models;

namespace CircuitModuleDesigner.Modules.SignalConversion.Engines;

internal static class SignalConversionPreferredValues
{
    public static double Nearest(double target,SignalConversionDesignRequest request,double minimum,double maximum)
    {
        if(!request.QuantizeComponents)return Math.Clamp(target,minimum,maximum);
        return AnalogPreferredValueSeries.Nearest(target,Map(request.PreferredSeries),minimum,maximum);
    }

    public static double AtOrBelow(double target,SignalConversionDesignRequest request,double minimum,double maximum)
    {
        if(!request.QuantizeComponents)return Math.Clamp(target,minimum,maximum);
        var values=AnalogPreferredValueSeries.All(Map(request.PreferredSeries),minimum,maximum);
        return values.LastOrDefault(value=>value<=target) is >0 and var selected
            ?selected
            :values.FirstOrDefault();
    }

    public static IReadOnlyList<double> Nearby(double target,SignalConversionDesignRequest request,double minimum,double maximum,int eachSide=4)=>
        request.QuantizeComponents
            ?AnalogPreferredValueSeries.Nearby(target,Map(request.PreferredSeries),minimum,maximum,eachSide)
            :[Math.Clamp(target,minimum,maximum)];

    private static AnalogStandardSeries Map(SignalConversionPreferredSeries series)=>series switch
    {
        SignalConversionPreferredSeries.E24=>AnalogStandardSeries.E24,
        SignalConversionPreferredSeries.E48=>AnalogStandardSeries.E48,
        _=>AnalogStandardSeries.E96
    };
}
