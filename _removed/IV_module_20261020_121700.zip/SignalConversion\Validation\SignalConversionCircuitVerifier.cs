using CircuitModuleDesigner.Core.Circuit;
using CircuitModuleDesigner.Modules.SignalConversion.Models;
using CircuitModuleDesigner.Modules.SignalConversion.Schematic;

namespace CircuitModuleDesigner.Modules.SignalConversion.Validation;

public sealed record SignalConversionVerificationPoint(double Input,double TargetOutput,double ActualOutput,string Range="");
public sealed record SignalConversionCircuitVerificationResult(
    bool Pass,double ActualSlope,double ActualOffset,double MaximumErrorPercent,
    IReadOnlyList<SignalConversionVerificationPoint> Points,IReadOnlyList<string> Failures);

/// <summary>
/// Independent selected-value DC verifier. Values and connectivity are read
/// from the generated CircuitGraph; candidate transfer coefficients are never
/// accepted as proof.
/// </summary>
public sealed class SignalConversionCircuitVerifier
{
    public SignalConversionCircuitVerificationResult Verify(SignalConversionCandidate candidate,SignalConversionDesignRequest request)
    {
        ArgumentNullException.ThrowIfNull(candidate);ArgumentNullException.ThrowIfNull(request);
        var graph=new SignalConversionCircuitFactory().Build(candidate,request);
        var target=SignalConversionTransferRequirement.For(request);
        return candidate.Topology switch
        {
            SignalConversionTopology.BasicTia=>VerifyTia(graph,request,target,0),
            SignalConversionTopology.BiasedTia=>VerifyTia(graph,request,target,Reference(graph,"RV","VREF",request)),
            SignalConversionTopology.MultiRangeTia=>VerifyMultiTia(graph,candidate,request),
            SignalConversionTopology.LowSideShuntAmplifier or SignalConversionTopology.HighSideShuntAmplifier=>VerifyShunt(graph,request,target),
            _=>throw new NotSupportedException($"{candidate.Topology} is not part of the I/V verifier.")
        };
    }

    private static SignalConversionCircuitVerificationResult VerifyTia(CircuitGraph graph,SignalConversionDesignRequest request,
        SignalConversionAffineRequirement target,double reference)
    {
        RequireNet(graph,"U1","IN-","IIN");RequireNet(graph,"U1","OUT","VOUT");
        var slope=-R(graph,"RF");
        return Affine(request,target,slope,reference);
    }

    private static SignalConversionCircuitVerificationResult VerifyMultiTia(CircuitGraph graph,SignalConversionCandidate candidate,
        SignalConversionDesignRequest request)
    {
        RequireNet(graph,"RSAFE","1","IIN");RequireNet(graph,"RSAFE","2","VOUT");
        var reference=Reference(graph,"RV","VREF",request);var safety=R(graph,"RSAFE");
        var points=new List<SignalConversionVerificationPoint>();var failures=new List<string>();var worst=0d;
        double reportedSlope=double.NaN;
        for(var index=1;index<=candidate.RangeCount;index++)
        {
            var range=candidate.Ranges.ElementAtOrDefault(index-1);
            if(range is null){failures.Add($"GAIN{index} has no range model.");continue;}
            RequireNet(graph,$"SW{index}","B","VOUT");RequireNet(graph,$"RF{index}","1","IIN");
            var branch=R(graph,$"RF{index}")+SwitchResistance(graph,$"SW{index}");
            var slope=-Parallel(branch,safety);reportedSlope=double.IsNaN(reportedSlope)?slope:reportedSlope;
            foreach(var input in new[]{range.InputMinimum,range.InputMaximum})
            {
                var targetOutput=range.TargetSlope*input+range.TargetOffset;var actual=reference+slope*input;
                points.Add(new(input,targetOutput,actual,range.Name));
                worst=Math.Max(worst,100*Math.Abs(actual-targetOutput)/Math.Max(request.OutputSpan,1e-30));
            }
        }
        if(worst>request.TargetAccuracyPercent)failures.Add($"Selected multi-range CircuitGraph transfer error {worst:G6}% exceeds target.");
        return new(failures.Count==0,reportedSlope,reference,worst,points,failures);
    }

    private static SignalConversionCircuitVerificationResult VerifyShunt(CircuitGraph graph,SignalConversionDesignRequest request,
        SignalConversionAffineRequirement target)
    {
        RequireNet(graph,"U1","OUT","VOUT");
        var r1=R(graph,"R1");var r2=R(graph,"R2");var r3=R(graph,"R3");var r4=R(graph,"R4");
        var gainMinus=r2/r1;var gainPlus=r4/r3;
        if(Math.Abs(gainMinus-gainPlus)>1e-12*Math.Max(1,gainMinus))
            throw new InvalidOperationException("Difference-amplifier resistor ratios are not balanced.");
        var slope=R(graph,"RSH")*gainMinus;var reference=Reference(graph,"RV","VREF",request);
        return Affine(request,target,slope,reference);
    }

    private static SignalConversionCircuitVerificationResult Affine(SignalConversionDesignRequest request,
        SignalConversionAffineRequirement target,double slope,double offset)
    {
        var points=new List<SignalConversionVerificationPoint>();var worst=0d;
        foreach(var input in new[]{request.InputMinimum,request.InputMaximum})
        {
            var expected=target.Evaluate(input);var actual=slope*input+offset;
            points.Add(new(input,expected,actual));worst=Math.Max(worst,100*Math.Abs(actual-expected)/Math.Max(request.OutputSpan,1e-30));
        }
        var pass=worst<=request.TargetAccuracyPercent;
        return new(pass,slope,offset,worst,points,pass?[]:[$"CircuitGraph endpoint transfer error {worst:G6}% exceeds target."]);
    }

    private static double Reference(CircuitGraph graph,string prefix,string outputNet,SignalConversionDesignRequest request)
    {
        if(graph.Components.Any(component=>component.Reference.Equals(prefix+"T",StringComparison.OrdinalIgnoreCase)))
        {
            var upper=R(graph,prefix+"T");var lower=R(graph,prefix+"B");
            return request.SupplyLowVoltage+(request.SupplyHighVoltage-request.SupplyLowVoltage)*lower/(upper+lower);
        }
        var probe=graph.Components.Any(component=>component.Reference.Equals("R4",StringComparison.OrdinalIgnoreCase))?("R4","2"):("U1","IN+");
        var connected=graph.GetNetForPin(probe.Item1,probe.Item2)?.Name??"GND";
        return connected.Equals("VCC",StringComparison.OrdinalIgnoreCase)?request.SupplyHighVoltage:
            connected.Equals("VEE",StringComparison.OrdinalIgnoreCase)?request.SupplyLowVoltage:0;
    }

    private static double R(CircuitGraph graph,string reference)=>graph.GetComponent(reference).Parameters.GetRequiredValue(ComponentParameterNames.ResistanceOhm);
    private static double SwitchResistance(CircuitGraph graph,string reference)=>graph.GetComponent(reference).Parameters.GetRequiredValue(ComponentParameterNames.ResistanceOhm);
    private static double Parallel(double a,double b)=>a*b/(a+b);
    private static void RequireNet(CircuitGraph graph,string component,string pin,string expected)
    {
        var actual=graph.GetNetForPin(component,pin)?.Name;
        if(!string.Equals(actual,expected,StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException($"{component}.{pin} is on {actual??"<unconnected>"}, expected {expected}.");
    }
}
