using CircuitModuleDesigner.Modules.SignalConversion.Models;

namespace CircuitModuleDesigner.Modules.SignalConversion.Validation;

public static class SignalConversionRequestValidator
{
    /// <param name="requireTopology">
    /// False is only used by the UI feasibility preview, which evaluates every
    /// topology before the user has picked one. Production design always
    /// requires an explicit selection.
    /// </param>
    public static IReadOnlyList<string> Validate(SignalConversionDesignRequest request,bool requireTopology=true)
    {
        ArgumentNullException.ThrowIfNull(request);
        var values=new Dictionary<string,double>
        {
            ["input minimum"]=request.InputMinimum,["input maximum"]=request.InputMaximum,
            ["output at input minimum"]=request.OutputAtInputMinimum,["output at input maximum"]=request.OutputAtInputMaximum,
            ["VCC"]=request.SupplyHighVoltage,["VEE"]=request.SupplyLowVoltage,["bandwidth"]=request.TargetBandwidthHz,
            ["accuracy"]=request.TargetAccuracyPercent,["minimum resolved current"]=request.MinimumResolvedInputMagnitude,
            ["input/sensor capacitance"]=request.InputAndSensorCapacitanceFarad,["feedback parasitic capacitance"]=request.FeedbackParasiticCapacitanceFarad,
            ["output load"]=request.OutputLoadResistanceOhm,["maximum burden"]=request.MaximumBurdenVoltage,
            ["maximum shunt power"]=request.MaximumShuntPowerWatt,["high-side common mode"]=request.HighSideCommonModeVoltage,
            ["op-amp GBW"]=request.OpAmpGainBandwidthHz,["op-amp output current"]=request.OpAmpOutputCurrentAmpere,
            ["op-amp bias current"]=request.OpAmpInputBiasCurrentAmpere,["op-amp offset"]=request.OpAmpInputOffsetVoltage,
            ["op-amp voltage noise"]=request.OpAmpVoltageNoiseVoltPerRootHz,["op-amp current noise"]=request.OpAmpCurrentNoiseAmperePerRootHz,
            ["op-amp input capacitance"]=request.OpAmpInputCapacitanceFarad,["op-amp common-mode minimum"]=request.OpAmpInputCommonModeMinimumVoltage,
            ["op-amp common-mode maximum"]=request.OpAmpInputCommonModeMaximumVoltage,["op-amp CMRR"]=request.OpAmpCommonModeRejectionDb,
            ["PCB leakage"]=request.PcbLeakageCurrentAmpere,["switch leakage"]=request.AnalogSwitchLeakageAmpere,
            ["switch on resistance"]=request.AnalogSwitchOnResistanceOhm,["switch parasitic capacitance"]=request.AnalogSwitchParasiticCapacitanceFarad,
            ["switch charge injection"]=request.AnalogSwitchChargeInjectionCoulomb
        };
        var errors=values.Where(pair=>!double.IsFinite(pair.Value)).Select(pair=>$"{pair.Key} must be finite.").ToList();
        if(errors.Count>0)return errors;
        if(requireTopology)
        {
            if(request.RequestedTopology is not { } topology)errors.Add("Select one I/V topology; automatic topology selection has been removed.");
            else if(!Enum.IsDefined(topology))errors.Add($"'{topology}' is not a valid I/V topology.");
        }
        if(request.InputMaximum<=request.InputMinimum)errors.Add("Input-current maximum must be greater than minimum.");
        if(request.OutputSpan<=0)errors.Add("The two mapped output voltages must differ.");
        if(request.SupplyHighVoltage<=request.SupplyLowVoltage)errors.Add("VCC must be greater than VEE.");
        if(request.TargetBandwidthHz<=0)errors.Add("Target bandwidth must be positive.");
        if(request.TargetAccuracyPercent is <=0 or >20)errors.Add("Target accuracy must be greater than 0% and no more than 20%.");
        if(request.OutputWindowMinimum<request.SupplyLowVoltage)
            errors.Add($"The low mapped output ({request.OutputWindowMinimum:G6} V) is below VEE ({request.SupplyLowVoltage:G6} V). Raise that endpoint or lower VEE.");
        if(request.OutputWindowMaximum>request.SupplyHighVoltage)
            errors.Add($"The high mapped output ({request.OutputWindowMaximum:G6} V) is above VCC ({request.SupplyHighVoltage:G6} V). Lower that endpoint or raise VCC.");
        if(request.InputAndSensorCapacitanceFarad<0||request.FeedbackParasiticCapacitanceFarad<0||request.OpAmpInputCapacitanceFarad<0)
            errors.Add("Capacitances must be nonnegative.");
        if(request.OutputLoadResistanceOhm<=0)errors.Add("Output-load resistance must be positive.");
        if(request.MaximumBurdenVoltage<=0||request.MaximumShuntPowerWatt<=0)errors.Add("Burden-voltage and shunt-power limits must be positive.");
        if(request.MinimumResolvedInputMagnitude<0)errors.Add("Minimum resolved current cannot be negative.");
        if(request.RangeOverlapPercent is <0 or >50)errors.Add("Range overlap must be between 0% and 50%.");
        if(request.OpAmpGainBandwidthHz<=0||request.OpAmpOutputCurrentAmpere<=0)errors.Add("Op-amp GBW and output-current capability must be positive.");
        if(request.OpAmpInputCommonModeMaximumVoltage<=request.OpAmpInputCommonModeMinimumVoltage)errors.Add("Op-amp common-mode maximum must exceed minimum.");
        if(request.OpAmpCommonModeRejectionDb<=0)errors.Add("Op-amp CMRR must be positive.");
        if(request.OpAmpInputBiasCurrentAmpere<0||request.OpAmpInputOffsetVoltage<0||request.OpAmpVoltageNoiseVoltPerRootHz<0||
           request.OpAmpCurrentNoiseAmperePerRootHz<0||request.PcbLeakageCurrentAmpere<0||request.AnalogSwitchLeakageAmpere<0||
           request.AnalogSwitchOnResistanceOhm<0||request.AnalogSwitchParasiticCapacitanceFarad<0||request.AnalogSwitchChargeInjectionCoulomb<0)
            errors.Add("Device error, noise, leakage and parasitic assumptions must be nonnegative.");
        if(request.ShuntResistanceTolerancePercent<0||request.ShuntTcrPpmPerC<0||request.EstimatedShuntTemperatureRiseC<0||request.DifferenceAmplifierRatioMatchPercent<0)
            errors.Add("Shunt tolerance, TCR, temperature rise and ratio mismatch must be nonnegative.");
        return errors;
    }
}
