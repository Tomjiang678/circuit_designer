using System.Text;
using CircuitModuleDesigner.Modules.Filters.FilterDesign.Controls;
using CircuitModuleDesigner.Modules.SignalConversion.Engines;
using CircuitModuleDesigner.Modules.SignalConversion.Models;
using CircuitModuleDesigner.Modules.SignalConversion.Schematic;
using CircuitModuleDesigner.Modules.SignalConversion.Validation;

namespace CircuitModuleDesigner.Modules.SignalConversion.Controls;

/// <summary>
/// Three-step I/V wizard: target mapping, engineering constraints including the
/// explicit topology choice, and the synthesized result. The former standalone
/// topology-evaluation step and the automatic topology option were removed: the
/// user always picks one of the five topologies and nothing is substituted.
/// </summary>
public sealed class SignalConversionWizardControl : UserControl
{
    private static readonly IReadOnlyList<EngineeringUnit> CurrentUnits=[new("fA",1e-15),new("pA",1e-12),new("nA",1e-9),new("uA",1e-6),new("mA",1e-3),new("A",1)];
    private static readonly IReadOnlyList<EngineeringUnit> VoltageUnits=[new("uV",1e-6),new("mV",1e-3),new("V",1)];
    private static readonly IReadOnlyList<EngineeringUnit> ResistanceUnits=[new("ohm",1),new("kohm",1e3),new("Mohm",1e6),new("Gohm",1e9)];
    private static readonly IReadOnlyList<EngineeringUnit> CapacitanceUnits=[new("pF",1e-12),new("nF",1e-9),new("uF",1e-6)];
    private static readonly IReadOnlyList<EngineeringUnit> PowerUnits=[new("mW",1e-3),new("W",1)];
    private readonly string[] titles=["1. I/V Target Mapping","2. Engineering Constraints","3. Design Result"];

    private readonly EngineeringValueInput ivInputMinimum=new(0,CurrentUnits,-1e3,1e3);
    private readonly EngineeringValueInput ivInputMaximum=new(100e-6,CurrentUnits,-1e3,1e3);
    private readonly EngineeringValueInput ivOutputMinimum=new(3.3,VoltageUnits,-1e3,1e3);
    private readonly EngineeringValueInput ivOutputMaximum=new(0,VoltageUnits,-1e3,1e3);
    private readonly EngineeringValueInput bandwidth=new(10_000,EngineeringUnits.Frequency,1,1e9);
    private readonly NumericUpDown vcc=Number(-1000,1000,5,3);
    private readonly NumericUpDown vee=Number(-1000,1000,0,3);
    private readonly NumericUpDown accuracy=Number(.001m,20,1,3);
    private readonly ComboBox preferredSeries=EnumBox<SignalConversionPreferredSeries>(SignalConversionPreferredSeries.E96);
    private readonly CheckBox preserveLoadGround=new(){Text="The load ground must not be lifted",AutoSize=true};
    private readonly CheckBox deviceParametersVerified=new(){Text="Values below come from a selected device datasheet/model",AutoSize=true};
    private readonly EngineeringValueInput inputCapacitance=new(50e-12,CapacitanceUnits,0,1);
    private readonly EngineeringValueInput feedbackParasitic=new(.2e-12,CapacitanceUnits,0,1);
    private readonly EngineeringValueInput ivOutputLoad=new(1e6,ResistanceUnits,1,1e12);
    private readonly EngineeringValueInput highSideCommonMode=new(2.5,VoltageUnits,-1e3,1e3);
    private readonly EngineeringValueInput maximumSenseVoltage=new(.1,VoltageUnits,1e-9,100);
    private readonly EngineeringValueInput maximumSensePower=new(.5,PowerUnits,1e-9,1e5);
    private readonly EngineeringValueInput minimumResolvedMagnitude=new(0,CurrentUnits,0,1e3);
    private readonly EngineeringValueInput opAmpGbw=new(10_000_000,EngineeringUnits.Frequency,1,1e12);
    private readonly EngineeringValueInput opAmpBiasCurrent=new(10e-12,CurrentUnits,0,1);
    private readonly EngineeringValueInput opAmpOffsetVoltage=new(50e-6,VoltageUnits,0,10);
    private readonly EngineeringValueInput opAmpCommonModeMinimum=new(0,VoltageUnits,-1e3,1e3);
    private readonly EngineeringValueInput opAmpCommonModeMaximum=new(5,VoltageUnits,-1e3,1e3);
    private readonly EngineeringValueInput pcbLeakage=new(1e-12,CurrentUnits,0,1);
    private readonly NumericUpDown rangeOverlap=Number(0,50,10,1);
    private readonly NumericUpDown cmrr=Number(1,200,100,1);
    private readonly CheckBox showAdvanced=new(){Text="Show advanced device, leakage and range assumptions",AutoSize=true};
    private readonly GroupBox advancedSection=new(){Text="Advanced assumptions",Dock=DockStyle.Fill,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Padding=new Padding(8,18,8,8),Visible=false};

    private readonly Label topologyStatus=new(){AutoSize=true,ForeColor=SystemColors.GrayText,MaximumSize=new Size(960,0),Padding=new Padding(4,8,4,4)};
    private readonly ToolTip topologyToolTip=new();
    private readonly Dictionary<SignalConversionTopology,RadioButton> topologyOptions=[];
    private readonly Panel pageHost=new(){Dock=DockStyle.Fill,Margin=Padding.Empty,Padding=new Padding(0,0,0,4)};
    private readonly Label stepTitle=new();private readonly Button backButton=new();private readonly Button nextButton=new();
    private readonly TabControl tabs=new(){Dock=DockStyle.Fill,Padding=new Point(12,4)};
    private readonly FilterSchematicControl topologyView=new(){Dock=DockStyle.Fill};
    private readonly SignalConversionTransferPlotControl transferView=new();
    private readonly RichTextBox details=new(){Dock=DockStyle.Fill,ReadOnly=true,Font=new Font("Consolas",9F),BackColor=SystemColors.Window,WordWrap=false};
    private readonly Dictionary<int,Control> pages=[];
    private TreeView? navigation;private SignalConversionDesignResult? renderedResult;private int currentIndex;
    private bool resultIsStale;private bool updatingNavigation;private bool synchronizing;private SignalConversionTopology? selectedTopology;

    public SignalConversionWizardControl()
    {
        Dock=DockStyle.Fill;AutoScaleMode=AutoScaleMode.Dpi;BackColor=SystemColors.Control;DoubleBuffered=true;
        BuildLayout();BuildPages();WireEvents();RefreshTopologyAvailability();ShowStep(0);
    }

    public SignalConversionDesignResult? CurrentResult=>renderedResult;
    public Control TopologyView=>topologyView;
    public Control TransferView=>transferView;

    /// <summary>Selects one of the five topologies explicitly. There is no automatic mode.</summary>
    public bool SelectTopology(SignalConversionTopology topology)
    {
        RefreshTopologyAvailability();
        if(!topologyOptions.TryGetValue(topology,out var option))return false;
        option.Checked=true;return selectedTopology==topology;
    }

    public void AttachNavigation(TreeView tree){if(ReferenceEquals(navigation,tree)){PopulateNavigation();return;}DetachNavigation();navigation=tree;navigation.AfterSelect+=NavigationAfterSelect;PopulateNavigation();}
    public void DetachNavigation(){if(navigation is not null)navigation.AfterSelect-=NavigationAfterSelect;navigation=null;}

    public SignalConversionDesignResult RunDesign()
    {
        try{renderedResult=new SignalConversionDesignEngine().Design(CreateRequest(true));}
        catch(Exception exception){renderedResult=new(){Request=CreateRequest(true),Candidates=[],Message=$"Design failed: {exception.Message}"};}
        Render(renderedResult);resultIsStale=false;
        if(!renderedResult.Success){ShowStep(1);topologyStatus.ForeColor=Color.Firebrick;topologyStatus.Text=renderedResult.Message;}else ShowStep(2);
        return renderedResult;
    }

    private void BuildLayout()
    {
        var root=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=3,Margin=Padding.Empty,Padding=Padding.Empty};
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));root.RowStyles.Add(new RowStyle(SizeType.Percent,100));root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        stepTitle.AutoSize=true;stepTitle.Dock=DockStyle.Fill;stepTitle.Font=new Font(Font,FontStyle.Bold);stepTitle.Padding=new Padding(8,7,8,7);
        var bar=new FlowLayoutPanel{Dock=DockStyle.Fill,AutoSize=true,FlowDirection=FlowDirection.RightToLeft,WrapContents=false,Padding=new Padding(6),Margin=Padding.Empty};
        nextButton.Text="Next >";nextButton.AutoSize=true;nextButton.MinimumSize=new Size(90,28);nextButton.Click+=(_,_)=>Advance();
        backButton.Text="< Back";backButton.AutoSize=true;backButton.MinimumSize=new Size(90,28);backButton.Click+=(_,_)=>ShowStep(currentIndex-1);
        bar.Controls.Add(nextButton);bar.Controls.Add(backButton);root.Controls.Add(stepTitle,0,0);root.Controls.Add(pageHost,0,1);root.Controls.Add(bar,0,2);Controls.Add(root);
    }

    private void BuildPages()
    {
        pages[0]=BuildTargetPage();pages[1]=BuildConstraintsPage();pages[2]=BuildResults();
        foreach(var page in pages.Values){page.Visible=false;pageHost.Controls.Add(page);}
    }

    private Control BuildTargetPage()
    {
        var form=FormLayout();AddRow(form,"Input current minimum (Imin):",ivInputMinimum);AddRow(form,"Input current maximum (Imax):",ivInputMaximum);
        AddRow(form,"Output voltage at Imin:",ivOutputMinimum);AddRow(form,"Output voltage at Imax:",ivOutputMaximum);
        AddRow(form,"Target bandwidth:",bandwidth);AddRow(form,"Target accuracy (%):",accuracy);
        var batch=new Button{Text="Batch Test (up to 1000)...",AutoSize=true,MinimumSize=new Size(190,30)};
        batch.Click+=(_,_)=>{using var dialog=new SignalConversionManualTestRowDialog();dialog.ShowDialog(FindForm());};AddRow(form,"Manual verification:",batch);
        var note=new Label{Text="The two output fields are an explicit endpoint mapping, not a sorted voltage window. Example: 0..100 uA -> 3.3..0 V is a valid inverting TIA request. Endpoints are checked only against VEE/VCC, and accuracy is a percentage of the full-scale current unless the advanced accuracy-reference current is set. The next page asks you to choose one of the five topologies; nothing is selected automatically.",AutoSize=true,MaximumSize=new Size(900,0),ForeColor=SystemColors.GrayText,Padding=new Padding(4,8,4,4)};
        var content=Flow();content.Controls.Add(form);content.Controls.Add(note);
        var page=PagePanel();page.Controls.Add(Section("Current-to-Voltage Requirement",content));return page;
    }

    private Control BuildConstraintsPage()
    {
        var form=FormLayout();AddRow(form,"Positive supply, VCC (V):",vcc);AddRow(form,"Negative supply / ground, VEE (V):",vee);
        AddRow(form,"Load-ground requirement:",preserveLoadGround);AddRow(form,"Input + sensor capacitance:",inputCapacitance);
        AddRow(form,"Output load resistance:",ivOutputLoad);AddRow(form,"Maximum shunt burden:",maximumSenseVoltage);AddRow(form,"Maximum shunt power:",maximumSensePower);
        AddRow(form,"High-side bus/common-mode:",highSideCommonMode);AddRow(form,"Preferred R/C series:",preferredSeries);AddRow(form,"Advanced:",showAdvanced);
        var advanced=FormLayout();AddRow(advanced,"Accuracy reference current (0 = full scale):",minimumResolvedMagnitude);AddRow(advanced,"Range overlap (%):",rangeOverlap);
        AddRow(advanced,"Feedback parasitic capacitance:",feedbackParasitic);AddRow(advanced,"PCB leakage assumption:",pcbLeakage);
        AddRow(advanced,"Op-amp GBW:",opAmpGbw);AddRow(advanced,"Op-amp input bias:",opAmpBiasCurrent);AddRow(advanced,"Op-amp input offset:",opAmpOffsetVoltage);
        AddRow(advanced,"Op-amp common-mode minimum:",opAmpCommonModeMinimum);AddRow(advanced,"Op-amp common-mode maximum:",opAmpCommonModeMaximum);AddRow(advanced,"Op-amp CMRR (dB):",cmrr);
        AddRow(advanced,"Device evidence:",deviceParametersVerified);advancedSection.Controls.Add(advanced);
        var stack=Stack();
        Add(stack,BuildTopologySection());
        Add(stack,Section("Supply, Load and Measurement Requirements",form));
        Add(stack,advancedSection);
        var page=PagePanel();page.Controls.Add(stack);return page;
    }

    private Control BuildTopologySection()
    {
        var choices=Flow();choices.Padding=new Padding(8,4,8,4);
        choices.Controls.Add(new Label{Text="Choose exactly one of the five topologies. Automatic selection was removed on request; the design uses your choice and never falls back to another topology.",AutoSize=true,MaximumSize=new Size(930,0),ForeColor=SystemColors.GrayText,Margin=new Padding(2,2,2,8)});
        AddTopologyChoice(choices,SignalConversionTopology.BasicTia);
        AddTopologyChoice(choices,SignalConversionTopology.BiasedTia);
        AddTopologyChoice(choices,SignalConversionTopology.MultiRangeTia);
        AddTopologyChoice(choices,SignalConversionTopology.LowSideShuntAmplifier);
        AddTopologyChoice(choices,SignalConversionTopology.HighSideShuntAmplifier);
        choices.Controls.Add(topologyStatus);
        return Section("I/V Topology (explicit selection)",choices);
    }

    private void AddTopologyChoice(Control parent,SignalConversionTopology topology)
    {
        // Every entry stays selectable so the user can always pick the topology
        // they want and read why it does or does not meet the target.
        var option=new RadioButton{Text=SignalConversionDesignEngine.Name(topology),AutoSize=true,Margin=new Padding(4,5,4,5),Tag=topology};
        option.CheckedChanged+=(_,_)=>{if(option.Checked&&!synchronizing){selectedTopology=topology;MarkChanged();}};
        topologyOptions[topology]=option;parent.Controls.Add(option);
    }

    private Control BuildResults()
    {
        tabs.TabPages.Add(ResultPage("Selected Circuit",topologyView));tabs.TabPages.Add(ResultPage("Transfer Analysis",transferView));
        tabs.TabPages.Add(ResultPage("Engineering Evidence and Candidates",details));return tabs;
    }

    private void WireEvents()
    {
        foreach(var input in new[]{ivInputMinimum,ivInputMaximum,ivOutputMinimum,ivOutputMaximum,bandwidth,inputCapacitance,feedbackParasitic,ivOutputLoad,
            highSideCommonMode,maximumSenseVoltage,maximumSensePower,minimumResolvedMagnitude,opAmpGbw,opAmpBiasCurrent,opAmpOffsetVoltage,opAmpCommonModeMinimum,opAmpCommonModeMaximum,pcbLeakage})
            input.ValueChanged+=(_,_)=>MarkChanged();
        foreach(var number in new[]{vcc,vee,accuracy,rangeOverlap,cmrr})number.ValueChanged+=(_,_)=>MarkChanged();
        preferredSeries.SelectedIndexChanged+=(_,_)=>MarkChanged();
        preserveLoadGround.CheckedChanged+=(_,_)=>MarkChanged();deviceParametersVerified.CheckedChanged+=(_,_)=>MarkChanged();
        showAdvanced.CheckedChanged+=(_,_)=>advancedSection.Visible=showAdvanced.Checked;
    }

    private void MarkChanged()
    {
        if(synchronizing)return;if(renderedResult is not null)resultIsStale=true;RefreshTopologyAvailability();
    }

    private SignalConversionDesignRequest CreateRequest(bool includeSelectedTopology)
    {
        return new()
        {
            RequestedTopology=includeSelectedTopology?selectedTopology:null,
            InputMinimum=ivInputMinimum.ValueBaseUnit,InputMaximum=ivInputMaximum.ValueBaseUnit,
            OutputAtInputMinimum=ivOutputMinimum.ValueBaseUnit,OutputAtInputMaximum=ivOutputMaximum.ValueBaseUnit,
            SupplyHighVoltage=(double)vcc.Value,SupplyLowVoltage=(double)vee.Value,TargetBandwidthHz=bandwidth.ValueBaseUnit,TargetAccuracyPercent=(double)accuracy.Value,
            MustPreserveLoadGround=preserveLoadGround.Checked,InputAndSensorCapacitanceFarad=inputCapacitance.ValueBaseUnit,
            FeedbackParasiticCapacitanceFarad=feedbackParasitic.ValueBaseUnit,OutputLoadResistanceOhm=ivOutputLoad.ValueBaseUnit,
            MaximumBurdenVoltage=maximumSenseVoltage.ValueBaseUnit,MaximumShuntPowerWatt=maximumSensePower.ValueBaseUnit,
            HighSideCommonModeVoltage=highSideCommonMode.ValueBaseUnit,MinimumResolvedInputMagnitude=minimumResolvedMagnitude.ValueBaseUnit,
            RangeOverlapPercent=(double)rangeOverlap.Value,PreferredSeries=preferredSeries.SelectedItem is SignalConversionPreferredSeries series?series:SignalConversionPreferredSeries.E96,
            DeviceParametersVerified=deviceParametersVerified.Checked,OpAmpGainBandwidthHz=opAmpGbw.ValueBaseUnit,
            OpAmpInputBiasCurrentAmpere=opAmpBiasCurrent.ValueBaseUnit,OpAmpInputOffsetVoltage=opAmpOffsetVoltage.ValueBaseUnit,
            OpAmpInputCommonModeMinimumVoltage=opAmpCommonModeMinimum.ValueBaseUnit,OpAmpInputCommonModeMaximumVoltage=opAmpCommonModeMaximum.ValueBaseUnit,
            OpAmpCommonModeRejectionDb=(double)cmrr.Value,PcbLeakageCurrentAmpere=pcbLeakage.ValueBaseUnit
        };
    }

    private void RefreshTopologyAvailability()
    {
        if(topologyOptions.Count==0||synchronizing)return;
        var request=CreateRequest(false);
        IReadOnlyList<string> errors=SignalConversionRequestValidator.Validate(request,requireTopology:false);
        IReadOnlyList<SignalConversionCandidate> preview=[];
        if(errors.Count==0)
        {
            try{preview=new SignalConversionDesignEngine().EvaluateCandidates(request);}
            catch(Exception exception){errors=[exception.Message];}
        }
        synchronizing=true;
        try
        {
            foreach(var pair in topologyOptions)
            {
                var candidate=preview.FirstOrDefault(item=>item.Topology==pair.Key);
                pair.Value.Enabled=true;
                pair.Value.Text=$"{SignalConversionDesignEngine.Name(pair.Key)}  [{FeasibilityLabel(candidate?.Feasibility)}]";
                topologyToolTip.SetToolTip(pair.Value,candidate is null
                    ?(errors.Count==0?"No candidate was produced.":string.Join(Environment.NewLine,errors))
                    :CandidateExplanation(candidate));
            }
        }
        finally{synchronizing=false;}
        UpdateTopologyStatus(preview,errors);
        UpdateStepButtons();
        UpdateNavigationState();
    }

    private void UpdateTopologyStatus(IReadOnlyList<SignalConversionCandidate> preview,IReadOnlyList<string> errors)
    {
        if(errors.Count>0)
        {
            topologyStatus.ForeColor=Color.Firebrick;
            topologyStatus.Text="Fix these inputs first: "+string.Join(" ",errors);
            return;
        }
        if(selectedTopology is not { } selected)
        {
            topologyStatus.ForeColor=Color.DarkOrange;
            topologyStatus.Text="No topology selected. Pick exactly one of the five options above; nothing is chosen automatically.";
            return;
        }
        var candidate=preview.FirstOrDefault(item=>item.Topology==selected);
        if(candidate is null)
        {
            topologyStatus.ForeColor=Color.Firebrick;
            topologyStatus.Text=$"{SignalConversionDesignEngine.Name(selected)}: no candidate was produced.";
            return;
        }
        if(candidate.IsSelectable)
        {
            topologyStatus.ForeColor=Color.DarkGreen;
            topologyStatus.Text=$"Selected: {SignalConversionDesignEngine.Name(selected)} — {FeasibilityLabel(candidate.Feasibility)}. It will be synthesized, standardized and re-verified from its generated CircuitGraph.";
            return;
        }
        var reasons=candidate.Constraints.Concat(candidate.Reasons).Take(3).ToArray();
        topologyStatus.ForeColor=Color.Firebrick;
        topologyStatus.Text=$"Selected: {SignalConversionDesignEngine.Name(selected)} — {FeasibilityLabel(candidate.Feasibility)}. {string.Join(" ",reasons)} No other topology is substituted automatically.";
    }

    private static string FeasibilityLabel(CandidateFeasibility? feasibility)=>feasibility switch
    {
        CandidateFeasibility.FullyFeasible=>"feasible",
        CandidateFeasibility.ConditionallyFeasible=>"feasible with declared assumptions",
        CandidateFeasibility.NotSuitable=>"not suitable",
        CandidateFeasibility.Infeasible=>"fails constraints",
        CandidateFeasibility.NotVerified=>"not verified",
        _=>"inputs need fixing"
    };

    private static string CandidateExplanation(SignalConversionCandidate candidate)
    {
        var b=new StringBuilder().AppendLine(candidate.Feasibility.ToString());
        foreach(var reason in candidate.Reasons)b.AppendLine("+ "+reason);foreach(var constraint in candidate.Constraints)b.AppendLine("- "+constraint);
        foreach(var check in candidate.Verification.Where(check=>check.Outcome!=VerificationOutcome.Pass))b.AppendLine($"[{check.Outcome}] {check.Name}: {check.Detail}");return b.ToString().Trim();
    }

    private bool ResultAvailable=>renderedResult?.Success==true&&!resultIsStale;

    private void ShowStep(int requestedIndex)
    {
        currentIndex=Math.Clamp(requestedIndex,0,ResultAvailable?2:1);stepTitle.Text=$"I/V Conversion — {titles[currentIndex]}";
        if(currentIndex==1)RefreshTopologyAvailability();foreach(var page in pages.Values)page.Visible=false;pages[currentIndex].Visible=true;pages[currentIndex].BringToFront();
        UpdateStepButtons();UpdateNavigationState();
    }

    private void UpdateStepButtons()
    {
        backButton.Enabled=currentIndex>0;
        nextButton.Enabled=currentIndex switch{0=>true,1=>ResultAvailable||selectedTopology is not null,_=>false};
        nextButton.Text=currentIndex==1?(ResultAvailable?"View Result >":"Synthesize && Verify >"):"Next >";
    }

    private void Advance()
    {
        if(currentIndex==1&&!ResultAvailable){RunDesign();return;}
        ShowStep(currentIndex+1);
    }

    private void PopulateNavigation(){if(navigation is null)return;updatingNavigation=true;navigation.Nodes.Clear();foreach(var title in titles)navigation.Nodes.Add(title);updatingNavigation=false;UpdateNavigationState();}
    private void NavigationAfterSelect(object? sender,TreeViewEventArgs e){if(!updatingNavigation&&e.Node is not null&&(e.Node.Index<2||ResultAvailable))ShowStep(e.Node.Index);}
    private void UpdateNavigationState()
    {
        if(navigation is null)return;updatingNavigation=true;
        for(var i=0;i<navigation.Nodes.Count&&i<titles.Length;i++){navigation.Nodes[i].Text=i==2&&resultIsStale?titles[i]+" (settings changed)":i<currentIndex?"✓ "+titles[i]:titles[i];navigation.Nodes[i].ForeColor=i==2&&!ResultAvailable?SystemColors.GrayText:SystemColors.WindowText;}
        if(navigation.Nodes.Count>currentIndex)navigation.SelectedNode=navigation.Nodes[currentIndex];updatingNavigation=false;
    }

    private void Render(SignalConversionDesignResult result)
    {
        transferView.Result=result;details.Text=BuildDetails(result);
        if(result.Recommended is null){topologyView.Document=null;return;}
        var graph=new SignalConversionCircuitFactory().Build(result.Recommended,result.Request);
        topologyView.Document=new SignalConversionSchematicLayoutService().Layout(graph,result.Recommended);
    }

    private static string BuildDetails(SignalConversionDesignResult result)
    {
        var b=new StringBuilder().AppendLine(result.Message)
            .AppendLine($"Target: VOUT = {result.TransferSlope:G9} * IIN {result.TransferOffset:+0.#########;-0.#########;+0}")
            .AppendLine($"Endpoint mapping: {result.Request.InputMinimum:G9} A -> {result.Request.OutputAtInputMinimum:G9} V; {result.Request.InputMaximum:G9} A -> {result.Request.OutputAtInputMaximum:G9} V");
        foreach(var candidate in result.Candidates)
        {
            b.AppendLine().AppendLine($"=== {SignalConversionDesignEngine.Name(candidate.Topology)} [{candidate.Feasibility}] ===")
                .AppendLine(candidate.Configuration).AppendLine($"Actual: VOUT = {candidate.ActualTransferSlope:G9} * IIN {candidate.ActualTransferOffset:+0.#########;-0.#########;+0}")
                .AppendLine($"Error={candidate.MaximumTransferErrorPercent:G6}%  BW={candidate.PredictedBandwidthHz:G6} Hz  Power={candidate.PredictedPowerWatt:G6} W");
            foreach(var reason in candidate.Reasons)b.AppendLine("  + "+reason);foreach(var constraint in candidate.Constraints)b.AppendLine("  - "+constraint);
            b.AppendLine("Error budget:");foreach(var item in candidate.ErrorBudget)b.AppendLine($"  [{item.Outcome,-11}] {item.Name}: {item.Percent:G6}% {item.Detail}");
            b.AppendLine("Verification:");foreach(var check in candidate.Verification)b.AppendLine($"  [{check.Outcome,-11}] {check.Name} {check.Detail}");
            if(candidate.Ranges.Count>0){b.AppendLine("GAIN ranges:");foreach(var range in candidate.Ranges)b.AppendLine($"  {range.Name}: I={range.InputMinimum:G6}..{range.InputMaximum:G6} A; V={range.OutputMinimum:G6}..{range.OutputMaximum:G6} V; RF gain={range.ActualSlope:G6} V/A; BW={range.PredictedBandwidthHz:G6} Hz; error={range.PredictedErrorPercent:G5}% [{range.Outcome}]");}
            foreach(var warning in candidate.Warnings)b.AppendLine("  ! "+warning);
            if(ReferenceEquals(candidate,result.Recommended)){b.AppendLine("Selected components:");foreach(var component in candidate.Components)b.AppendLine($"  {component.Reference,-7} {component.Role,-38} {component.Value:G9} {component.Unit} {component.Note}");}
        }
        return b.ToString();
    }

    protected override void Dispose(bool disposing){if(disposing)DetachNavigation();base.Dispose(disposing);}
    private static Panel PagePanel()=>new(){Dock=DockStyle.Fill,BackColor=SystemColors.Control,Padding=new Padding(8),AutoScroll=true};
    private static NumericUpDown Number(decimal min,decimal max,decimal value,int decimals)=>new(){Minimum=min,Maximum=max,Value=value,DecimalPlaces=decimals,Width=132,ThousandsSeparator=true};
    private static ComboBox EnumBox<T>(T selected) where T:struct,Enum{var box=new ComboBox{DropDownStyle=ComboBoxStyle.DropDownList,Width=260};box.Items.AddRange(Enum.GetValues<T>().Cast<object>().ToArray());box.SelectedItem=selected;return box;}
    private static Label FieldLabel(string text)=>new(){Text=text,AutoSize=true,Anchor=AnchorStyles.Left,Margin=new Padding(2,6,10,4)};
    private static TableLayoutPanel FormLayout(){var form=new TableLayoutPanel{Dock=DockStyle.Top,AutoSize=true,ColumnCount=2,RowCount=0,Padding=new Padding(4),Margin=Padding.Empty,GrowStyle=TableLayoutPanelGrowStyle.AddRows};form.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));form.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));return form;}
    private static void AddRow(TableLayoutPanel form,string label,Control input){var row=form.RowCount++;form.RowStyles.Add(new RowStyle(SizeType.AutoSize));form.Controls.Add(FieldLabel(label),0,row);input.Anchor=AnchorStyles.Left;input.Margin=new Padding(2,3,2,3);form.Controls.Add(input,1,row);}
    private static GroupBox Section(string title,Control content){var section=new GroupBox{Text=title,Dock=DockStyle.Top,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,Padding=new Padding(8,18,8,8),Margin=Padding.Empty};section.Controls.Add(content);return section;}
    private static TabPage ResultPage(string title,Control child){var page=new TabPage(title){BackColor=SystemColors.Window};page.Controls.Add(child);return page;}
    private static FlowLayoutPanel Flow()=>new(){Dock=DockStyle.Top,AutoSize=true,FlowDirection=FlowDirection.TopDown,WrapContents=false};
    private static TableLayoutPanel Stack(){var stack=new TableLayoutPanel{Dock=DockStyle.Top,AutoSize=true,ColumnCount=1,RowCount=0,GrowStyle=TableLayoutPanelGrowStyle.AddRows,Margin=Padding.Empty,Padding=Padding.Empty};stack.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));return stack;}
    private static void Add(TableLayoutPanel stack,Control control){var row=stack.RowCount++;stack.RowStyles.Add(new RowStyle(SizeType.AutoSize));control.Dock=DockStyle.Fill;control.Margin=new Padding(0,0,0,6);stack.Controls.Add(control,0,row);}
}
