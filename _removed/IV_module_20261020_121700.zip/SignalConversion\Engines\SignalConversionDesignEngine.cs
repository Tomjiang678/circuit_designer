using CircuitModuleDesigner.Modules.SignalConversion.Models;
using CircuitModuleDesigner.Modules.SignalConversion.Validation;

namespace CircuitModuleDesigner.Modules.SignalConversion.Engines;

/// <summary>
/// Current-to-voltage synthesis only. Every topology is evaluated so the UI can
/// show why a topology does or does not fit, but the design itself always uses
/// the <see cref="SignalConversionDesignRequest.RequestedTopology"/> the user
/// picked: there is no automatic selection and no fallback to another topology.
/// </summary>
public sealed class SignalConversionDesignEngine
{
    private const double Boltzmann=1.380649e-23;

    public SignalConversionDesignResult Design(SignalConversionDesignRequest request)
    {
        var errors=SignalConversionRequestValidator.Validate(request);
        if(errors.Count>0)return new(){Request=request,Candidates=[],TransferSlope=double.NaN,TransferOffset=double.NaN,Message=string.Join(" ",errors)};

        var target=SignalConversionTransferRequirement.For(request);
        var candidates=BuildCandidates(request,target);
        var requested=request.RequestedTopology!.Value;
        var selected=candidates.FirstOrDefault(candidate=>candidate.Topology==requested&&candidate.IsSelectable);
        var rejected=candidates.First(candidate=>candidate.Topology==requested);
        var explanation=rejected.Constraints.Count>0?rejected.Constraints:rejected.Reasons;
        var ordered=candidates.OrderBy(candidate=>candidate.Topology==requested?0:1)
            .ThenBy(FeasibilityRank).ThenBy(candidate=>candidate.Components.Count)
            .ThenBy(candidate=>candidate.MaximumTransferErrorPercent).ToArray();
        return new()
        {
            Request=request,Candidates=ordered,Recommended=selected,TransferSlope=target.Slope,TransferOffset=target.Offset,
            Message=selected is not null
                ?$"Selected {Name(requested)} because it was chosen explicitly; it passed hard-constraint, selected-value, device-assumption and CircuitGraph checks."
                :rejected.Feasibility==CandidateFeasibility.NotSuitable
                    ?$"{Name(requested)} cannot implement this request: {Join(explanation)} No other topology is substituted automatically."
                    :$"{Name(requested)} failed verification: {Join(explanation)} No other topology is substituted automatically."
        };
    }

    /// <summary>
    /// Evaluates all five topologies without selecting one. Used by the wizard to
    /// annotate each radio button and by the manual batch report; it never
    /// changes the production selection rules.
    /// </summary>
    public IReadOnlyList<SignalConversionCandidate> EvaluateCandidates(SignalConversionDesignRequest request)
    {
        var errors=SignalConversionRequestValidator.Validate(request,requireTopology:false);
        if(errors.Count>0)return [];
        return BuildCandidates(request,SignalConversionTransferRequirement.For(request));
    }

    private static IReadOnlyList<SignalConversionCandidate> BuildCandidates(SignalConversionDesignRequest request,SignalConversionAffineRequirement target)
    {
        var multiRangePlan=PlanRanges(request,multiRange:true);
        return new[]
        {
            BuildSingleTia(request,target,SignalConversionTopology.BasicTia),
            BuildSingleTia(request,target,SignalConversionTopology.BiasedTia),
            BuildMultiRangeTia(request,target,multiRangePlan),
            BuildShunt(request,target,false),
            BuildShunt(request,target,true)
        }.Select(candidate=>VerifyGeneratedCircuit(candidate,request)).ToArray();
    }

    private static string Join(IReadOnlyCollection<string> values)=>values.Count==0?"no reason was reported.":string.Join(" ",values.Take(3));

    private static SignalConversionCandidate VerifyGeneratedCircuit(SignalConversionCandidate candidate,SignalConversionDesignRequest request)
    {
        if(!candidate.IsSelectable)return candidate;
        try
        {
            var result=new SignalConversionCircuitVerifier().Verify(candidate,request);
            var check=new SignalConversionVerification("Independent CircuitGraph DC transfer",
                result.Pass?VerificationOutcome.Pass:VerificationOutcome.Fail,request.TargetAccuracyPercent,result.MaximumErrorPercent,"%",
                "Recomputed from the generated nets and selected component values, independently of the stored transfer coefficients.");
            if(result.Pass)return candidate with
            {
                Verification=[..candidate.Verification,check],ActualTransferSlope=result.ActualSlope,
                ActualTransferOffset=result.ActualOffset,MaximumTransferErrorPercent=Math.Max(candidate.MaximumTransferErrorPercent,result.MaximumErrorPercent)
            };
            return candidate with
            {
                Feasibility=CandidateFeasibility.Infeasible,Constraints=[..candidate.Constraints,..result.Failures],
                Verification=[..candidate.Verification,check],ActualTransferSlope=result.ActualSlope,
                ActualTransferOffset=result.ActualOffset,MaximumTransferErrorPercent=Math.Max(candidate.MaximumTransferErrorPercent,result.MaximumErrorPercent)
            };
        }
        catch(Exception exception)
        {
            return candidate with
            {
                Feasibility=CandidateFeasibility.Infeasible,
                Constraints=[..candidate.Constraints,$"Generated CircuitGraph verification failed: {exception.Message}"],
                Verification=[..candidate.Verification,new("Independent CircuitGraph DC transfer",VerificationOutcome.Fail,Detail:exception.Message)]
            };
        }
    }

    private static SignalConversionCandidate BuildSingleTia(SignalConversionDesignRequest r,SignalConversionAffineRequirement target,SignalConversionTopology topology)
    {
        var constraints=new List<string>();var unsuitable=new List<string>();var warnings=new List<string>();
        var checks=new List<SignalConversionVerification>();var errors=new List<SignalConversionErrorContribution>();var components=new List<SignalConversionComponent>();
        if(target.Slope>=0)unsuitable.Add("Positive current is defined into the summing node, so an inverting TIA requires a negative I/V slope.");

        var theoreticalRf=Math.Abs(target.Slope);
        var basic=topology==SignalConversionTopology.BasicTia;
        var feedback=SelectTiaFeedback(r,target,theoreticalRf,basic);
        var rf=feedback.Rf;var actualSlope=-rf;var requiredReference=feedback.Reference;
        ReferenceNetwork reference;
        if(basic)
        {
            reference=new([],0,0,false,"GND");
            var allowed=Math.Max(1e-6,r.OutputSpan*r.TargetAccuracyPercent/400);
            if(Math.Abs(target.Offset)>allowed)unsuitable.Add($"Basic TIA ties IN+ to ground, but the requested endpoint mapping requires VREF={target.Offset:G6} V.");
            if(0<r.OpAmpInputCommonModeMinimumVoltage||0>r.OpAmpInputCommonModeMaximumVoltage)
                constraints.Add("Ground is outside the declared op-amp input common-mode range.");
        }
        else reference=BuildReference(r,requiredReference,"RV","TIA reference",true);
        if(reference.Net=="OUT_OF_RANGE")constraints.Add($"Required VREF={requiredReference:G6} V cannot be generated from the declared rails.");
        if(reference.ActualVoltage<r.OpAmpInputCommonModeMinimumVoltage||reference.ActualVoltage>r.OpAmpInputCommonModeMaximumVoltage)
            constraints.Add($"VREF={reference.ActualVoltage:G6} V is outside the declared op-amp input common-mode range.");
        components.Add(new("RF","Selected transimpedance feedback",rf,"ohm",SeriesNote(r,theoreticalRf)));components.AddRange(reference.Components);

        var totalInputCap=r.InputAndSensorCapacitanceFarad+r.OpAmpInputCapacitanceFarad;
        var minimumEffectiveCf=Math.Sqrt(totalInputCap/Math.Max(2*Math.PI*rf*r.OpAmpGainBandwidthHz,1e-30));
        var targetDiscreteCf=Math.Max(.1e-12,minimumEffectiveCf*1.15-r.FeedbackParasiticCapacitanceFarad);
        var cf=SignalConversionPreferredValues.Nearest(targetDiscreteCf,r,.1e-12,10e-6);
        var effectiveCf=cf+r.FeedbackParasiticCapacitanceFarad;var bandwidth=TiaBandwidth(r,rf,effectiveCf,totalInputCap);
        components.Add(new("CF","Feedback compensation capacitor",cf,"F",$"Effective CF includes {r.FeedbackParasiticCapacitanceFarad:G4} F parasitic; analytical minimum {minimumEffectiveCf:G6} F."));
        var compensationPass=effectiveCf>=minimumEffectiveCf*.98;
        checks.Add(new("TIA analytical noise-gain compensation",compensationPass?VerificationOutcome.Pass:VerificationOutcome.Fail,
            minimumEffectiveCf,effectiveCf,"F","Checks the input-capacitance/GBW crossover; it is not a phase-margin simulation."));
        checks.Add(new("TIA closed-loop bandwidth",bandwidth>=r.TargetBandwidthHz?VerificationOutcome.Pass:VerificationOutcome.Fail,
            r.TargetBandwidthHz,bandwidth,"Hz","Limited by feedback pole, capacitive noise gain and op-amp GBW."));
        checks.Add(new("TIA phase margin",VerificationOutcome.NotVerified,Detail:"Requires the selected op-amp open-loop model, sensor capacitance and PCB parasitics in AC loop-gain analysis."));
        if(!compensationPass)constraints.Add("The selected standard CF is below the analytical stability estimate.");
        if(bandwidth<r.TargetBandwidthHz)constraints.Add($"Estimated closed-loop bandwidth {bandwidth:G6} Hz is below target.");

        var actualOffset=basic?0:reference.ActualVoltage;AddOutputEnvelopeChecks(r,actualSlope,actualOffset,constraints,checks);
        var minimumCurrent=MeaningfulCurrent(r);var accuracyBase=AccuracyBase(r);var noise=TiaInputNoise(r,rf,totalInputCap,Math.Min(bandwidth,r.TargetBandwidthHz));
        AddError(errors,"RF standard-value/tolerance",SeriesTolerance(r),r,"Selected feedback resistance and assumed series tolerance.");
        AddError(errors,"Input bias current",100*r.OpAmpInputBiasCurrentAmpere/Math.Max(accuracyBase,1e-30),r);
        AddError(errors,"PCB/surface leakage",100*r.PcbLeakageCurrentAmpere/Math.Max(accuracyBase,1e-30),r);
        AddError(errors,"Input offset voltage",100*r.OpAmpInputOffsetVoltage/Math.Max(accuracyBase*rf,1e-30),r);
        AddError(errors,"Integrated input noise (6 sigma)",100*6*noise/Math.Max(accuracyBase,1e-30),r,$"Input-referred RMS={noise:G6} A.");
        AddError(errors,"Reference generation",100*Math.Abs(reference.ActualVoltage-requiredReference)/Math.Max(r.OutputSpan,1e-30),r);
        var transferError=TransferErrorPercent(r,target,actualSlope,actualOffset);AddError(errors,"Endpoint mapping",transferError,r);
        var totalError=RootSumSquare(errors.Select(item=>item.Percent).ToArray());
        if(totalError>r.TargetAccuracyPercent)constraints.Add($"RSS error budget {totalError:G5}% exceeds {r.TargetAccuracyPercent:G5}%.");

        var peakFeedbackCurrent=Math.Max(Math.Abs(r.InputMinimum),Math.Abs(r.InputMaximum));
        var peakOutput=new[]{actualSlope*r.InputMinimum+actualOffset,actualSlope*r.InputMaximum+actualOffset}.Max(Math.Abs);
        var requiredOutputCurrent=peakFeedbackCurrent+peakOutput/r.OutputLoadResistanceOhm;
        checks.Add(new("Op-amp output-current budget",requiredOutputCurrent<=r.OpAmpOutputCurrentAmpere?VerificationOutcome.Pass:VerificationOutcome.Fail,
            r.OpAmpOutputCurrentAmpere,requiredOutputCurrent,"A"));
        if(requiredOutputCurrent>r.OpAmpOutputCurrentAmpere)constraints.Add("Feedback plus output-load current exceeds the declared op-amp capability.");
        if(minimumCurrent<=1e-9||r.PcbLeakageCurrentAmpere>minimumCurrent*r.TargetAccuracyPercent/100)
            warnings.Add("pA/nA work requires an electrometer-grade input, guard ring, clean high-insulation PCB, guarded connectors and a measured leakage budget.");
        if(reference.RequiresBuffer)warnings.Add("The generated VREF divider is buffered; divider impedance, bias-current droop and thermal noise are included.");
        warnings.Add("Op-amp limits are declared assumptions until a real part and macromodel are selected.");
        var feasibility=Classify(r,constraints,unsuitable,checks);
        return Make(topology,basic?"Ground-referenced RF || CF TIA":"Buffered-VREF RF || CF TIA",feasibility,
            [basic?"Fewest components when the required reference is ground.":"Implements the required affine offset with a loaded, buffered reference."],
            [..unsuitable,..constraints],components,totalError,bandwidth,0,actualSlope,actualOffset,checks,warnings,errors,1,[]);
    }

    private static SignalConversionCandidate BuildMultiRangeTia(SignalConversionDesignRequest r,SignalConversionAffineRequirement target,RangePlan plan)
    {
        var constraints=new List<string>();var unsuitable=new List<string>();var warnings=new List<string>();
        var checks=new List<SignalConversionVerification>();var errors=new List<SignalConversionErrorContribution>();
        var components=new List<SignalConversionComponent>();var ranges=new List<SignalConversionRangeDesign>();
        if(target.Slope>=0)unsuitable.Add("Positive current into a TIA summing node requires a negative output slope.");
        if(plan.Count<2)unsuitable.Add("The declared resolution, noise floor and dynamic range did not produce at least two gain ranges.");

        var bipolar=r.InputMinimum<0&&r.InputMaximum>0;
        var referenceTarget=bipolar?(r.OutputWindowMinimum+r.OutputWindowMaximum)/2:
            r.InputMaximum<=0?r.OutputWindowMinimum:r.OutputWindowMaximum;
        var reference=BuildReference(r,referenceTarget,"RV","TIA common range reference",true);components.AddRange(reference.Components);
        if(reference.Net=="OUT_OF_RANGE")constraints.Add("The common range reference cannot be generated from the declared rails.");
        if(reference.ActualVoltage<r.OpAmpInputCommonModeMinimumVoltage||reference.ActualVoltage>r.OpAmpInputCommonModeMaximumVoltage)
            constraints.Add("The common range reference is outside the declared op-amp input common-mode range.");

        var totalCap=r.InputAndSensorCapacitanceFarad+r.OpAmpInputCapacitanceFarad+r.AnalogSwitchParasiticCapacitanceFarad;
        var usableSwing=bipolar?r.OutputSpan/2:r.OutputSpan;var maximumRf=.95*usableSwing/Math.Max(plan.MinimumMagnitude,1e-30);
        var safetyRf=SignalConversionPreferredValues.Nearest(Math.Min(1e12,Math.Max(1,maximumRf*1000)),r,1,1e12);
        components.Add(new("RSAFE","Permanent high-value safety feedback",safetyRf,"ohm","Prevents open-loop operation during GAIN transitions."));
        components.Add(new("CSAFE","Safety feedback compensation",SignalConversionPreferredValues.Nearest(1e-12,r,.1e-12,1e-6),"F","Always connected with RSAFE."));
        var minimumBandwidth=double.PositiveInfinity;var maximumError=0d;
        for(var index=0;index<plan.Count;index++)
        {
            var magnitude=plan.Ranges[index];var rfTarget=.95*usableSwing/Math.Max(magnitude.MaximumMagnitude,1e-30);
            var branchRf=SignalConversionPreferredValues.Nearest(rfTarget,r,1,1e12);
            var effectiveRf=Parallel(branchRf+r.AnalogSwitchOnResistanceOhm,safetyRf);
            var cfMinimum=Math.Sqrt(totalCap/Math.Max(2*Math.PI*effectiveRf*r.OpAmpGainBandwidthHz,1e-30));
            var cf=SignalConversionPreferredValues.Nearest(Math.Max(.1e-12,cfMinimum*1.15-r.FeedbackParasiticCapacitanceFarad),r,.1e-12,10e-6);
            var effectiveCf=cf+r.FeedbackParasiticCapacitanceFarad;var bandwidth=TiaBandwidth(r,effectiveRf,effectiveCf,totalCap);
            var rangeMin=bipolar?-magnitude.MaximumMagnitude:r.InputMaximum<=0?-magnitude.MaximumMagnitude:magnitude.MinimumMagnitude;
            var rangeMax=bipolar?magnitude.MaximumMagnitude:r.InputMaximum<=0?-magnitude.MinimumMagnitude:magnitude.MaximumMagnitude;
            var slope=-effectiveRf;var outA=reference.ActualVoltage+slope*rangeMin;var outB=reference.ActualVoltage+slope*rangeMax;
            var rangeBase=r.MinimumResolvedInputMagnitude>0
                ?Math.Clamp(r.MinimumResolvedInputMagnitude,magnitude.MinimumMagnitude,magnitude.MaximumMagnitude)
                :magnitude.MaximumMagnitude;
            rangeBase=Math.Max(rangeBase,1e-30);
            var leakagePercent=100*(r.AnalogSwitchLeakageAmpere*(plan.Count-1)+r.PcbLeakageCurrentAmpere)/rangeBase;
            var noise=TiaInputNoise(r,effectiveRf,totalCap,Math.Min(bandwidth,r.TargetBandwidthHz));
            var error=RootSumSquare(SeriesTolerance(r),100*r.AnalogSwitchOnResistanceOhm/Math.Max(branchRf,1e-30),
                leakagePercent,100*r.OpAmpInputBiasCurrentAmpere/rangeBase,
                100*6*noise/rangeBase);
            var outcome=error<=r.TargetAccuracyPercent&&bandwidth>=r.TargetBandwidthHz&&effectiveCf>=cfMinimum*.98?VerificationOutcome.Pass:VerificationOutcome.Fail;
            ranges.Add(new($"GAIN{index+1}",rangeMin,rangeMax,-rfTarget,referenceTarget,slope,reference.ActualVoltage,
                Math.Min(outA,outB),Math.Max(outA,outB),bandwidth,noise,error,outcome,
                $"{r.RangeOverlapPercent:G4}% overlap; permanent safety feedback remains closed during switching."));
            components.Add(new($"RF{index+1}",$"GAIN{index+1} feedback resistor",branchRf,"ohm",SeriesNote(r,rfTarget)));
            components.Add(new($"CF{index+1}",$"GAIN{index+1} compensation capacitor",cf,"F",$"Effective CF={effectiveCf:G6} F."));
            components.Add(new($"SW{index+1}",$"GAIN{index+1} feedback switch",r.AnalogSwitchOnResistanceOhm,"ohm",
                $"Leakage {r.AnalogSwitchLeakageAmpere:G4} A; Coff {r.AnalogSwitchParasiticCapacitanceFarad:G4} F; charge injection {r.AnalogSwitchChargeInjectionCoulomb:G4} C."));
            if(outcome==VerificationOutcome.Fail)constraints.Add($"GAIN{index+1} fails its selected-value error, bandwidth or compensation check.");
            maximumError=Math.Max(maximumError,error);minimumBandwidth=Math.Min(minimumBandwidth,bandwidth);
        }
        AddError(errors,"Worst range error budget",maximumError,r);
        checks.Add(new("Every GAIN range",ranges.All(range=>range.Outcome==VerificationOutcome.Pass)?VerificationOutcome.Pass:VerificationOutcome.Fail,
            Detail:"Each range has independent RF, CF, noise, leakage, bandwidth and output-window calculations."));
        checks.Add(new("Permanent safety feedback",VerificationOutcome.Pass,Detail:"RSAFE || CSAFE remains connected while switched branches change state, preventing an open-loop interval."));
        checks.Add(new("GAIN switching transient",VerificationOutcome.NotVerified,Detail:"Requires a selected switch model, source impedance and transient simulation of charge injection and settling."));
        if(reference.RequiresBuffer)warnings.Add("The shared VREF is buffered.");
        warnings.Add("Switch GAIN by enabling the new branch, waiting for overlap/settling, disabling the old branch, then resuming acquisition; RSAFE remains connected throughout.");
        if(plan.MinimumMagnitude<=1e-9)warnings.Add("At pA/nA levels switch leakage, board leakage and dielectric absorption require guarded low-leakage layout and a characterized switch.");
        var feasibility=Classify(r,constraints,unsuitable,checks);
        return Make(SignalConversionTopology.MultiRangeTia,$"{plan.Count}-range switched RF || CF TIA with permanent safety feedback",feasibility,
            ["Range count follows declared resolution, noise, accuracy, overlap and usable output swing rather than a fixed ratio."],
            [..unsuitable,..constraints],components,maximumError,minimumBandwidth,0,ranges.FirstOrDefault()?.ActualSlope??double.NaN,
            reference.ActualVoltage,checks,warnings,errors,plan.Count,ranges);
    }

    private static SignalConversionCandidate BuildShunt(SignalConversionDesignRequest r,SignalConversionAffineRequirement target,bool highSide)
    {
        var constraints=new List<string>();var unsuitable=new List<string>();var warnings=new List<string>();
        var checks=new List<SignalConversionVerification>();var errors=new List<SignalConversionErrorContribution>();
        if(target.Slope<=0)unsuitable.Add("A passive shunt followed by the supported difference amplifier has positive I/V polarity.");
        if(!highSide&&r.MustPreserveLoadGround)unsuitable.Add("Low-side shunt insertion lifts the load return and violates the preserve-load-ground requirement.");

        var maxCurrent=Math.Max(Math.Abs(r.InputMinimum),Math.Abs(r.InputMaximum));var accuracyBase=AccuracyBase(r);
        var upperByDrop=r.MaximumBurdenVoltage/Math.Max(maxCurrent,1e-30);
        var upperByPower=r.MaximumShuntPowerWatt/Math.Max(maxCurrent*maxCurrent,1e-30);
        var upper=Math.Min(upperByDrop,upperByPower);
        var lowerByOffset=r.OpAmpInputOffsetVoltage/Math.Max(accuracyBase*r.TargetAccuracyPercent/100,1e-30);
        var shuntCandidates=SignalConversionPreferredValues.Nearby(upper,r,1e-9,1e6,24).Where(value=>value<=upper*1.0000001).OrderByDescending(value=>value).ToArray();
        var shunt=shuntCandidates.FirstOrDefault(value=>value>=lowerByOffset);
        if(shunt<=0)shunt=SignalConversionPreferredValues.AtOrBelow(upper,r,1e-9,1e6);
        if(upper<=0||shunt<=0)constraints.Add("No positive standard shunt value satisfies burden and power limits.");
        var burden=maxCurrent*shunt;var shuntPower=maxCurrent*maxCurrent*shunt;
        var gainTarget=Math.Abs(target.Slope)/Math.Max(shunt,1e-30);var ratio=SelectRatio(gainTarget,r,100,10_000_000);
        var gain=ratio.Numerator/ratio.Denominator;var actualSlope=shunt*gain;
        var referenceTarget=BestAffineReference(r,actualSlope,target);var reference=BuildReference(r,referenceTarget,"RV","Difference-amplifier output reference",true);
        if(reference.Net=="OUT_OF_RANGE")constraints.Add("The required output reference cannot be generated from the declared rails.");
        var components=new List<SignalConversionComponent>
        {
            new("RSH","Four-terminal Kelvin current shunt",shunt,"ohm",$"Burden={burden:G6} V; Pmax={shuntPower:G6} W; TCR={r.ShuntTcrPpmPerC:G5} ppm/C."),
            new("R1","Difference-amplifier low-side input arm",ratio.Denominator,"ohm"),
            new("R2","Difference-amplifier feedback arm",ratio.Numerator,"ohm"),
            new("R3","Difference-amplifier high-side input arm",ratio.Denominator,"ohm"),
            new("R4","Difference-amplifier reference arm",ratio.Numerator,"ohm")
        };components.AddRange(reference.Components);
        var actualOffset=reference.ActualVoltage;var transferError=TransferErrorPercent(r,target,actualSlope,actualOffset);
        var noiseVoltage=Math.Sqrt(Math.Pow(r.OpAmpVoltageNoiseVoltPerRootHz,2)+4*Boltzmann*298.15*shunt)*Math.Sqrt(r.TargetBandwidthHz);
        var commonMode=Math.Abs(highSide?r.HighSideCommonModeVoltage:0);
        var cmrrErrorVoltage=commonMode/Math.Pow(10,r.OpAmpCommonModeRejectionDb/20)*gain;
        var ratioCommonModeError=commonMode*r.DifferenceAmplifierRatioMatchPercent/100;
        AddError(errors,"Endpoint mapping / standard values",transferError,r);
        AddError(errors,"Shunt tolerance",r.ShuntResistanceTolerancePercent,r);
        AddError(errors,"Shunt TCR and estimated rise",r.ShuntTcrPpmPerC*r.EstimatedShuntTemperatureRiseC/10_000,r);
        AddError(errors,"Difference-pair ratio matching",r.DifferenceAmplifierRatioMatchPercent,r);
        AddError(errors,"Op-amp offset",100*r.OpAmpInputOffsetVoltage/Math.Max(accuracyBase*shunt,1e-30),r);
        AddError(errors,"Integrated input noise (6 sigma)",100*6*noiseVoltage/Math.Max(accuracyBase*shunt,1e-30),r);
        AddError(errors,"High-side common-mode conversion",100*(cmrrErrorVoltage+ratioCommonModeError)/Math.Max(r.OutputSpan,1e-30),r);
        var totalError=RootSumSquare(errors.Select(item=>item.Percent).ToArray());
        if(burden>r.MaximumBurdenVoltage*1.000001)constraints.Add("Selected shunt exceeds the maximum burden voltage.");
        if(shuntPower>r.MaximumShuntPowerWatt*1.000001)constraints.Add("Selected shunt exceeds the maximum dissipation.");
        if(totalError>r.TargetAccuracyPercent)constraints.Add($"RSS shunt/amplifier error budget {totalError:G5}% exceeds target.");
        var bandwidth=r.OpAmpGainBandwidthHz/Math.Max(1+gain,1);if(bandwidth<r.TargetBandwidthHz)constraints.Add("Difference-amplifier bandwidth is below target.");
        AddOutputEnvelopeChecks(r,actualSlope,actualOffset,constraints,checks);

        var pinMinimum=double.PositiveInfinity;var pinMaximum=double.NegativeInfinity;
        foreach(var current in new[]{r.InputMinimum,r.InputMaximum})
        {
            var differential=current*shunt;
            var high=highSide?r.HighSideCommonModeVoltage+differential/2:differential;
            var low=highSide?r.HighSideCommonModeVoltage-differential/2:0;
            var plusPin=(gain*high+reference.ActualVoltage)/(1+gain);
            var output=actualSlope*current+actualOffset;
            var minusPin=(gain*output+low)/(1+gain);
            pinMinimum=Math.Min(pinMinimum,Math.Min(plusPin,minusPin));pinMaximum=Math.Max(pinMaximum,Math.Max(plusPin,minusPin));
        }
        var commonModePass=pinMinimum>=r.OpAmpInputCommonModeMinimumVoltage&&pinMaximum<=r.OpAmpInputCommonModeMaximumVoltage;
        checks.Add(new("Actual op-amp input-pin common mode",commonModePass?VerificationOutcome.Pass:VerificationOutcome.Fail,
            Detail:$"Solved IN+/IN- span {pinMinimum:G6}..{pinMaximum:G6} V; declared device range {r.OpAmpInputCommonModeMinimumVoltage:G6}..{r.OpAmpInputCommonModeMaximumVoltage:G6} V."));
        if(!commonModePass)constraints.Add("Solved op-amp input-pin voltage exceeds the declared common-mode range.");
        checks.Add(new("Burden voltage",burden<=r.MaximumBurdenVoltage?VerificationOutcome.Pass:VerificationOutcome.Fail,r.MaximumBurdenVoltage,burden,"V"));
        checks.Add(new("Shunt dissipation",shuntPower<=r.MaximumShuntPowerWatt?VerificationOutcome.Pass:VerificationOutcome.Fail,r.MaximumShuntPowerWatt,shuntPower,"W"));
        checks.Add(new("Selected-value four-resistor transfer",transferError<=r.TargetAccuracyPercent?VerificationOutcome.Pass:VerificationOutcome.Fail,r.TargetAccuracyPercent,transferError,"%"));
        checks.Add(new("Difference-amplifier bandwidth",bandwidth>=r.TargetBandwidthHz?VerificationOutcome.Pass:VerificationOutcome.Fail,r.TargetBandwidthHz,bandwidth,"Hz"));
        checks.Add(new("Device parameter provenance",r.DeviceParametersVerified?VerificationOutcome.Pass:VerificationOutcome.NotVerified,
            Detail:"Common-mode range, CMRR, output swing, GBW, offset and output current require a selected amplifier datasheet/model."));
        if(highSide)warnings.Add("High-side feasibility is based on solved amplifier pin voltages plus declared CMRR/common-mode limits; select a high-common-mode amplifier and verify resistor voltage ratings.");
        warnings.Add("Use a four-terminal shunt and Kelvin routing; the TCR/temperature-rise term remains an estimate until thermal characterization.");
        if(reference.RequiresBuffer)warnings.Add("The output-bias divider is buffered in the generated circuit.");
        var feasibility=Classify(r,constraints,unsuitable,checks);
        return Make(highSide?SignalConversionTopology.HighSideShuntAmplifier:SignalConversionTopology.LowSideShuntAmplifier,
            highSide?"High-side Kelvin shunt with matched difference amplifier":"Low-side Kelvin shunt with matched difference amplifier",feasibility,
            [highSide?"Preserves load ground after explicit pin common-mode and CMRR checks.":"Simplest shunt path when return-path burden is permitted."],
            [..unsuitable,..constraints],components,totalError,bandwidth,shuntPower,actualSlope,actualOffset,checks,warnings,errors,1,[]);
    }

    private static CandidateFeasibility Classify(SignalConversionDesignRequest request,IReadOnlyCollection<string> constraints,
        IReadOnlyCollection<string> unsuitable,IReadOnlyCollection<SignalConversionVerification> checks)
    {
        if(unsuitable.Count>0)return CandidateFeasibility.NotSuitable;
        if(constraints.Count>0||checks.Any(check=>check.Outcome==VerificationOutcome.Fail))return CandidateFeasibility.Infeasible;
        if(checks.Any(check=>check.Outcome==VerificationOutcome.NotVerified)||!request.DeviceParametersVerified)
            return CandidateFeasibility.ConditionallyFeasible;
        return CandidateFeasibility.FullyFeasible;
    }

    private static SignalConversionCandidate Make(SignalConversionTopology topology,string configuration,CandidateFeasibility feasibility,
        IReadOnlyList<string> reasons,IReadOnlyList<string> constraints,IReadOnlyList<SignalConversionComponent> components,double accuracy,double bandwidth,double power,
        double actualSlope,double actualOffset,IReadOnlyList<SignalConversionVerification> checks,IReadOnlyList<string> warnings,
        IReadOnlyList<SignalConversionErrorContribution> errorBudget,int rangeCount,IReadOnlyList<SignalConversionRangeDesign> ranges)=>
        new(topology,configuration,feasibility,reasons,constraints,components,accuracy,bandwidth,power,rangeCount)
        {
            ActualTransferSlope=actualSlope,ActualTransferOffset=actualOffset,MaximumTransferErrorPercent=accuracy,
            EvidenceLevel=EngineeringEvidenceLevel.VerifiedFromCircuit,Verification=checks,Warnings=warnings,ErrorBudget=errorBudget,Ranges=ranges
        };

    private static ReferenceNetwork BuildReference(SignalConversionDesignRequest r,double target,string prefix,string role,bool forceBuffer)
    {
        var low=r.SupplyLowVoltage;var high=r.SupplyHighVoltage;var span=high-low;
        if(Math.Abs(target)<=1e-12&&low<=0&&high>=0)return new([],0,0,false,"GND");
        if(Math.Abs(target-low)<=1e-12)return new([],low,0,false,Math.Abs(low)<1e-12?"GND":"VEE");
        if(Math.Abs(target-high)<=1e-12)return new([],high,0,false,"VCC");
        if(target<low||target>high)return new([],target,double.PositiveInfinity,true,"OUT_OF_RANGE");
        var fraction=(target-low)/span;var total=Math.Clamp(100_000/Math.Max(Math.Min(fraction,1-fraction),.02),10_000,1_000_000);
        var upperTarget=total*(1-fraction);var lowerTarget=total*fraction;
        var best=(Upper:upperTarget,Lower:lowerTarget,Error:double.PositiveInfinity);
        foreach(var upper in SignalConversionPreferredValues.Nearby(upperTarget,r,10,1_000_000,8))
        foreach(var lower in SignalConversionPreferredValues.Nearby(lowerTarget,r,10,1_000_000,8))
        {
            var actual=low+span*lower/(upper+lower);var error=Math.Abs(actual-target);
            if(error<best.Error)best=(upper,lower,error);
        }
        var voltage=low+span*best.Lower/(best.Upper+best.Lower);var impedance=Parallel(best.Upper,best.Lower);
        var biasDroop=r.OpAmpInputBiasCurrentAmpere*impedance;
        var thermalNoise=Math.Sqrt(4*Boltzmann*298.15*impedance*r.TargetBandwidthHz);
        var allowed=Math.Max(1e-6,r.OutputSpan*r.TargetAccuracyPercent/400);
        var buffer=forceBuffer||biasDroop+6*thermalNoise>allowed;
        var components=new List<SignalConversionComponent>
        {
            new(prefix+"T",role+" upper divider",best.Upper,"ohm",$"Target {target:G9} V"),
            new(prefix+"B",role+" lower divider",best.Lower,"ohm",$"Actual {voltage:G9} V; Rth {impedance:G6} ohm")
        };
        if(buffer)components.Add(new(prefix+"BUF",role+" buffer",1,"device","Voltage follower isolates the divider from signal-network loading."));
        return new(components,voltage,impedance,buffer,"VREF");
    }

    private static RatioPair SelectRatio(double target,SignalConversionDesignRequest r,double minimum,double maximum)
    {
        var denominatorTarget=Math.Clamp(100_000,minimum,maximum);RatioPair? best=null;var bestError=double.PositiveInfinity;
        foreach(var denominator in SignalConversionPreferredValues.Nearby(denominatorTarget,r,minimum,maximum,18))
        foreach(var numerator in SignalConversionPreferredValues.Nearby(target*denominator,r,minimum,maximum,18))
        {
            var error=Math.Abs(numerator/denominator-target)/Math.Max(target,1e-30);
            if(error<bestError){bestError=error;best=new(denominator,numerator);}
        }
        return best??new(denominatorTarget,Math.Clamp(target*denominatorTarget,minimum,maximum));
    }

    private static RangePlan PlanRanges(SignalConversionDesignRequest r,bool multiRange)
    {
        var maximum=Math.Max(Math.Abs(r.InputMinimum),Math.Abs(r.InputMaximum));var minimum=MeaningfulCurrent(r);
        var accuracyLimitedRatio=Math.Clamp(25/Math.Max(r.TargetAccuracyPercent,.01),8,300);
        var noiseFloor=Math.Max(r.OpAmpInputBiasCurrentAmpere+r.PcbLeakageCurrentAmpere,1e-30);
        var usableMinimum=Math.Max(minimum,noiseFloor*100/Math.Max(r.TargetAccuracyPercent,.01));
        var dynamic=maximum/Math.Max(usableMinimum,1e-30);
        var count=multiRange
            ?Math.Clamp((int)Math.Ceiling(Math.Log(Math.Max(1,dynamic))/Math.Log(accuracyLimitedRatio)),2,6)
            :1;
        var ranges=new List<RangeMagnitude>();var high=maximum;var overlap=1+Math.Clamp(r.RangeOverlapPercent,0,50)/100;
        for(var i=0;i<count;i++)
        {
            var low=i==count-1?usableMinimum:Math.Max(usableMinimum,high/accuracyLimitedRatio);
            ranges.Add(new(low,high));high=Math.Min(high,low*overlap);
        }
        return new(usableMinimum,maximum,ranges);
    }

    private static double TiaBandwidth(SignalConversionDesignRequest r,double rf,double effectiveCf,double inputCap)
    {
        var feedbackPole=1/(2*Math.PI*rf*effectiveCf);
        var gbwCapLimit=Math.Sqrt(r.OpAmpGainBandwidthHz/Math.Max(2*Math.PI*rf*inputCap,1e-30));
        var noiseGainLimit=r.OpAmpGainBandwidthHz/(1+inputCap/effectiveCf);
        return Math.Min(feedbackPole,Math.Min(gbwCapLimit,noiseGainLimit));
    }

    private static double TiaInputNoise(SignalConversionDesignRequest r,double rf,double totalCap,double bandwidth)
    {
        var resistorNoise=Math.Sqrt(4*Boltzmann*298.15/rf);var voltageResistive=r.OpAmpVoltageNoiseVoltPerRootHz/rf;
        var voltageCapacitive=r.OpAmpVoltageNoiseVoltPerRootHz*2*Math.PI*bandwidth*totalCap/Math.Sqrt(3);
        return RootSumSquare(resistorNoise,r.OpAmpCurrentNoiseAmperePerRootHz,voltageResistive,voltageCapacitive)*Math.Sqrt(Math.Max(1,bandwidth));
    }

    private static void AddOutputEnvelopeChecks(SignalConversionDesignRequest r,double slope,double offset,List<string> constraints,List<SignalConversionVerification> checks)
    {
        var outputs=new[]{slope*r.InputMinimum+offset,slope*r.InputMaximum+offset};var low=outputs.Min();var high=outputs.Max();
        var allowedLow=r.SupplyLowVoltage;var allowedHigh=r.SupplyHighVoltage;
        var tolerance=r.OutputSpan*r.TargetAccuracyPercent/100;var pass=low>=allowedLow-tolerance&&high<=allowedHigh+tolerance;
        checks.Add(new("Actual selected-value output swing",pass?VerificationOutcome.Pass:VerificationOutcome.Fail,
            Detail:$"Actual {low:G6}..{high:G6} V; supply rails {allowedLow:G6}..{allowedHigh:G6} V."));
        if(!pass)constraints.Add("Selected-value endpoint output leaves the supply rails.");
    }

    private static void AddError(List<SignalConversionErrorContribution> budget,string name,double percent,SignalConversionDesignRequest request,string detail="")=>
        budget.Add(new(name,percent,percent<=request.TargetAccuracyPercent?VerificationOutcome.Pass:VerificationOutcome.Fail,detail));
    private static double BestAffineReference(SignalConversionDesignRequest r,double actualSlope,SignalConversionAffineRequirement target)=>
        ((target.Evaluate(r.InputMinimum)-actualSlope*r.InputMinimum)+(target.Evaluate(r.InputMaximum)-actualSlope*r.InputMaximum))/2;

    /// <summary>
    /// Co-selects the standard feedback resistor and the reference voltage. The
    /// nominal |slope| alone is not enough: with a full-swing endpoint mapping
    /// the required reference can land a few millivolts outside the rails after
    /// E-series quantization, which previously rejected otherwise usable
    /// designs. Candidates are limited to references that stay inside the supply
    /// rails and the declared input common-mode range, and the endpoint error is
    /// minimized inside the accuracy budget.
    /// </summary>
    private static (double Rf,double Reference) SelectTiaFeedback(SignalConversionDesignRequest r,SignalConversionAffineRequirement target,
        double theoreticalRf,bool basic)
    {
        var nearest=SignalConversionPreferredValues.Nearest(theoreticalRf,r,1,1e12);
        (double Rf,double Reference,double Error)? best=null;
        if(basic)
        {
            foreach(var candidate in SignalConversionPreferredValues.Nearby(theoreticalRf,r,1,1e12,6))
            {
                var error=TransferErrorPercent(r,target,-candidate,0);
                if(best is null||error<best.Value.Error||
                   Math.Abs(error-best.Value.Error)<=1e-15&&Math.Abs(candidate-theoreticalRf)<Math.Abs(best.Value.Rf-theoreticalRf))
                    best=(candidate,0,error);
            }
            return best is { } zeroReference?(zeroReference.Rf,0):(nearest,0);
        }

        var allowedLow=Math.Max(r.SupplyLowVoltage,r.OpAmpInputCommonModeMinimumVoltage);
        var allowedHigh=Math.Min(r.SupplyHighVoltage,r.OpAmpInputCommonModeMaximumVoltage);
        if(allowedHigh<allowedLow)return (nearest,BestAffineReference(r,-nearest,target));
        var tolerance=Math.Max(1e-12,r.OutputSpan*r.TargetAccuracyPercent/100);
        foreach(var candidate in SignalConversionPreferredValues.Nearby(theoreticalRf,r,1,1e12,8))
        {
            var slope=-candidate;
            var reference=Math.Clamp(BestAffineReference(r,slope,target),allowedLow,allowedHigh);
            var atMinimum=slope*r.InputMinimum+reference;var atMaximum=slope*r.InputMaximum+reference;
            if(atMinimum<r.SupplyLowVoltage-tolerance||atMinimum>r.SupplyHighVoltage+tolerance)continue;
            if(atMaximum<r.SupplyLowVoltage-tolerance||atMaximum>r.SupplyHighVoltage+tolerance)continue;
            var error=TransferErrorPercent(r,target,slope,reference);
            if(best is null||error<best.Value.Error||
               Math.Abs(error-best.Value.Error)<=1e-15&&Math.Abs(candidate-theoreticalRf)<Math.Abs(best.Value.Rf-theoreticalRf))
                best=(candidate,reference,error);
        }
        return best is { } selected?(selected.Rf,selected.Reference):(nearest,BestAffineReference(r,-nearest,target));
    }

    private static double TransferErrorPercent(SignalConversionDesignRequest r,SignalConversionAffineRequirement target,double slope,double offset)=>
        100*new[]{r.InputMinimum,r.InputMaximum}.Max(input=>Math.Abs((slope*input+offset)-target.Evaluate(input)))/Math.Max(r.OutputSpan,1e-30);
    private static double MeaningfulCurrent(SignalConversionDesignRequest r)
    {
        if(r.MinimumResolvedInputMagnitude>0)return r.MinimumResolvedInputMagnitude;
        var nonzero=new[]{Math.Abs(r.InputMinimum),Math.Abs(r.InputMaximum)}.Where(value=>value>0).ToArray();
        if(r.InputMinimum!=0&&r.InputMaximum!=0&&Math.Sign(r.InputMinimum)==Math.Sign(r.InputMaximum))return nonzero.Min();
        return Math.Max(nonzero.DefaultIfEmpty(1).Max()*r.TargetAccuracyPercent/100,1e-30);
    }

    /// <summary>
    /// Reference current for the error budget. The user can declare a stricter
    /// minimum resolved current; otherwise "target accuracy" is a percentage of
    /// the full-scale current of the range. Using the automatically derived
    /// minimum (accuracy% of full scale) here would silently demand 100x better
    /// absolute accuracy than the entered number and rejected nearly every
    /// 0-based shunt design.
    /// </summary>
    private static double AccuracyBase(SignalConversionDesignRequest r)
    {
        var peak=Math.Max(Math.Abs(r.InputMinimum),Math.Abs(r.InputMaximum));
        if(r.MinimumResolvedInputMagnitude<=0)return Math.Max(peak,1e-30);
        var floor=Math.Min(Math.Abs(r.InputMinimum),Math.Abs(r.InputMaximum));
        var reference=floor>0?Math.Clamp(r.MinimumResolvedInputMagnitude,floor,peak):Math.Min(r.MinimumResolvedInputMagnitude,peak);
        return Math.Max(reference,1e-30);
    }
    private static double SeriesTolerance(SignalConversionDesignRequest r)=>r.PreferredSeries switch
    {SignalConversionPreferredSeries.E24=>1,SignalConversionPreferredSeries.E48=>.5,_=>.1};
    private static string SeriesNote(SignalConversionDesignRequest r,double theoretical)=>r.QuantizeComponents?$"Theoretical {theoretical:G9}; selected {r.PreferredSeries}":"Continuous theoretical value";
    private static double RootSumSquare(params double[] values)=>Math.Sqrt(values.Sum(value=>value*value));
    private static double Parallel(double a,double b)=>a*b/Math.Max(a+b,1e-30);
    private static int FeasibilityRank(SignalConversionCandidate candidate)=>candidate.Feasibility switch
    {CandidateFeasibility.FullyFeasible=>0,CandidateFeasibility.ConditionallyFeasible=>1,CandidateFeasibility.NotVerified=>2,CandidateFeasibility.NotSuitable=>3,_=>4};

    private sealed record ReferenceNetwork(IReadOnlyList<SignalConversionComponent> Components,double ActualVoltage,double OutputImpedance,bool RequiresBuffer,string Net);
    private sealed record RatioPair(double Denominator,double Numerator);
    private sealed record RangeMagnitude(double MinimumMagnitude,double MaximumMagnitude);
    private sealed record RangePlan(double MinimumMagnitude,double MaximumMagnitude,IReadOnlyList<RangeMagnitude> Ranges){public int Count=>Ranges.Count;}

    public static string Name(SignalConversionTopology topology)=>topology switch
    {
        SignalConversionTopology.BasicTia=>"Basic TIA",
        SignalConversionTopology.BiasedTia=>"Biased TIA",
        SignalConversionTopology.MultiRangeTia=>"Programmable-Gain / Multi-Range TIA",
        SignalConversionTopology.LowSideShuntAmplifier=>"Low-Side Shunt + Op-Amp",
        SignalConversionTopology.HighSideShuntAmplifier=>"High-Side Shunt + Op-Amp",
        _=>topology.ToString()
    };
}
