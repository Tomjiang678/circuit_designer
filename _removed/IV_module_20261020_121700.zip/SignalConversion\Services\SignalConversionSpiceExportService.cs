using CircuitModuleDesigner.Core.Circuit.Spice;
using CircuitModuleDesigner.Modules.SignalConversion.Models;
using CircuitModuleDesigner.Modules.SignalConversion.Schematic;

namespace CircuitModuleDesigner.Modules.SignalConversion.Services;

public sealed record SignalConversionSpiceArtifact(bool Available,string Netlist,string Status);

/// <summary>
/// Produces a DC-sweep deck from the same CircuitGraph used by the UI.  Export
/// availability is deliberately narrower than analytical support: switched TIA
/// ranges require an explicit switch model and selected GAIN state.
/// </summary>
public sealed class SignalConversionSpiceExportService
{
    public SignalConversionSpiceArtifact Export(SignalConversionDesignResult result)
    {
        ArgumentNullException.ThrowIfNull(result);
        if(result.Recommended is null)return new(false,string.Empty,"NOT VERIFIED: no feasible circuit was selected.");
        var candidate=result.Recommended;
        if(candidate.Topology is SignalConversionTopology.MultiRangeTia)
            return new(false,string.Empty,"NOT VERIFIED: an explicit analog-switch model and selected GAIN state are required.");
        if(candidate.Topology is SignalConversionTopology.HighSideShuntAmplifier)
            return new(false,string.Empty,"NOT VERIFIED: high-side SPICE verification requires the selected bus/load source network and a high-common-mode amplifier macromodel.");
        var request=result.Request;var graph=new SignalConversionCircuitFactory().Build(candidate,request);
        var start=request.InputMinimum;var stop=request.InputMaximum;var step=(stop-start)/100;
        var sources=new List<SpiceIndependentSource>
        {
            new("I_INPUT",SpiceSourceKind.Current,"IIN","0",start),
            new("VCC_SUPPLY",SpiceSourceKind.Voltage,"VCC","0",request.SupplyHighVoltage)
        };
        if(Math.Abs(request.SupplyLowVoltage)>1e-15)
            sources.Add(new("VEE_SUPPLY",SpiceSourceKind.Voltage,"VEE","0",request.SupplyLowVoltage));
        var options=new CircuitSpiceExportOptions($"{candidate.Topology} selected-value DC verification")
        {
            Sources=sources,
            Analyses=[new SpiceDcAnalysis("I_INPUT",start,stop,step)],
            OutputExpressions=["V(VOUT)"],
            OpAmpMode=SpiceOpAmpExportMode.FiniteGainVcvs,
            OpAmpOpenLoopGain=1e6,
            AdditionalComments=
            [
                "Generated from the same selected-value CircuitGraph shown in the application.",
                "Finite-gain VCVS op-amps do not prove rail swing, noise, phase margin, output current or overload recovery.",
                "A PASS requires execution with selected vendor macromodels; this file is an exportable verification deck, not a completed simulation."
            ]
        };
        return new(true,new CircuitSpiceExporter().Export(graph,options),
            "NETLIST GENERATED; simulation result NOT VERIFIED until run with selected device macromodels.");
    }
}
