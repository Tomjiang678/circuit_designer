using System.Globalization;
using System.Text;
using CircuitModuleDesigner.Modules.SignalConversion.Engines;
using CircuitModuleDesigner.Modules.SignalConversion.Models;

namespace CircuitModuleDesigner.Modules.SignalConversion.Services;

/// <summary>One input-current range of the 500-point range sweep.</summary>
public sealed record SignalConversionRangePoint(int Index,string Name,string Shape,double InputMinimum,double InputMaximum)
{
    public double PeakMagnitude=>Math.Max(Math.Abs(InputMinimum),Math.Abs(InputMaximum));
    public double Ratio=>InputMinimum==0?double.PositiveInfinity:PeakMagnitude/Math.Min(Math.Abs(InputMinimum),Math.Abs(InputMaximum));
}

/// <summary>Best feasibility reached by one topology, including the output mapping that reached it.</summary>
public sealed record SignalConversionRangeVerdict(SignalConversionTopology Topology,CandidateFeasibility Feasibility,string Mapping)
{
    public bool Suitable=>Feasibility is CandidateFeasibility.FullyFeasible or CandidateFeasibility.ConditionallyFeasible;
}

public sealed record SignalConversionRangeEvaluation(
    SignalConversionRangePoint Point,
    string BestMapping,
    int SuitableCount,
    IReadOnlyList<SignalConversionTopology> SuitableTopologies,
    IReadOnlyList<SignalConversionRangeVerdict> Verdicts,
    string Blocker,
    SignalConversionDesignRequest BestRequest);

/// <summary>
/// Builds and evaluates a 500-point sweep over input-current ranges only. Every
/// point is evaluated with several natural output mappings (inverting and
/// non-inverting full swing, plus zero-referenced variants when the range does
/// not cross zero) so the reported count answers "how many of the five
/// topologies can implement this current range at all", not "how many fit one
/// arbitrary sign convention".
/// </summary>
public sealed class SignalConversionRangeSweepService
{
    public const int PointCount=500;
    public const double SupplyLowVoltage=0;
    public const double SupplyHighVoltage=5;
    public const double TargetAccuracyPercent=1;
    public const double TargetBandwidthHz=10_000;

    private readonly SignalConversionDesignEngine engine=new();

    public IReadOnlyList<SignalConversionRangePoint> CreatePoints()
    {
        var peaks=Enumerable.Range(0,25).Select(index=>1e-12*Math.Pow(10,.5*index)).ToArray();
        var configs=new List<(double Ratio,int Shape)>();
        foreach(var ratio in new[]{10d,100d,1e3,1e4})
            for(var shape=0;shape<4;shape++)configs.Add((ratio,shape));
        configs.Add((0,16));configs.Add((0,17));configs.Add((0,18));configs.Add((0,19));
        foreach(var ratio in new[]{3d,30d,300d,3000d})
            for(var shape=0;shape<4;shape++)configs.Add((ratio,shape));

        var points=new List<SignalConversionRangePoint>(PointCount);var seen=new HashSet<(double,double)>();
        foreach(var (ratio,shape) in configs)
        {
            if(points.Count>=PointCount)break;
            foreach(var peak in peaks)
            {
                if(points.Count>=PointCount)break;
                var (minimum,maximum,name)=Shape(shape,peak,ratio);
                Add(minimum,maximum,name);
            }
        }
        return points;

        void Add(double minimum,double maximum,string name)
        {
            if(!(minimum<maximum))return;
            if(minimum!=0&&Math.Abs(minimum)<1e-15)minimum=Math.Sign(minimum)*1e-15;
            if(maximum!=0&&Math.Abs(maximum)<1e-15)maximum=Math.Sign(maximum)*1e-15;
            if(!(minimum<maximum)||!seen.Add((minimum,maximum)))return;
            points.Add(new(points.Count+1,$"R{points.Count+1:000}_{name}",name,minimum,maximum));
        }
    }

    public IReadOnlyList<SignalConversionRangeEvaluation> EvaluateAll()
    {
        var evaluations=new List<SignalConversionRangeEvaluation>(PointCount);
        foreach(var point in CreatePoints())evaluations.Add(Evaluate(point));
        return evaluations;
    }

    /// <summary>Writes the batch input, the full matrix and the summary with one evaluation pass.</summary>
    public void WriteAll(string directory)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(directory);
        Directory.CreateDirectory(directory);
        var evaluations=EvaluateAll();
        File.WriteAllText(Path.Combine(directory,"IV_500_INPUT_RANGE_TEST_POINTS.txt"),BuildBatchTestPointsText(evaluations));
        File.WriteAllText(Path.Combine(directory,"IV_500_INPUT_RANGE_MATRIX.txt"),BuildMatrixText(evaluations));
        File.WriteAllText(Path.Combine(directory,"IV_500_INPUT_RANGE_SUMMARY.md"),BuildSummaryMarkdown(evaluations));
    }

    public SignalConversionRangeEvaluation Evaluate(SignalConversionRangePoint point)
    {
        var mappings=Mappings(point);
        var best=new Dictionary<SignalConversionTopology,(CandidateFeasibility Feasibility,string Mapping,string Reason)>();
        var perMapping=new Dictionary<string,int>(StringComparer.Ordinal);
        var requests=new Dictionary<string,SignalConversionDesignRequest>(StringComparer.Ordinal);
        foreach(var (label,minimum,maximum) in mappings)
        {
            var request=Request(point,minimum,maximum);requests[label]=request;
            var candidates=engine.EvaluateCandidates(request);var suitable=0;
            foreach(var candidate in candidates)
            {
                if(candidate.IsSelectable)suitable++;
                if(!best.TryGetValue(candidate.Topology,out var current)||Rank(candidate.Feasibility)<Rank(current.Feasibility))
                    best[candidate.Topology]=(candidate.Feasibility,label,BlockReason(candidate));
            }
            perMapping[label]=suitable;
        }
        var ordered=best.Select(pair=>new SignalConversionRangeVerdict(pair.Key,pair.Value.Feasibility,pair.Value.Mapping))
            .OrderBy(verdict=>Rank(verdict.Feasibility)).ThenBy(verdict=>verdict.Topology).ToArray();
        var suitableTopologies=ordered.Where(verdict=>verdict.Suitable).Select(verdict=>verdict.Topology).ToArray();
        var bestMapping=perMapping.OrderByDescending(pair=>pair.Value).Select(pair=>pair.Key).First();
        var nearest=ordered.FirstOrDefault();
        var blockerText=suitableTopologies.Length>0?"—"
            :nearest is null?"No candidate was produced."
            :$"{SignalConversionDesignEngine.Name(nearest.Topology)} [{nearest.Feasibility}] {best[nearest.Topology].Reason}";
        // A batch row needs a concrete mapping + explicit topology pair. Use the
        // pair that actually reached a suitable verdict (the row's best mapping
        // may be a different mapping than the one that suits that topology).
        var batchVerdict=ordered.FirstOrDefault(verdict=>verdict.Suitable)??nearest;
        var batchRequest=batchVerdict is null?requests[bestMapping]
            :requests[batchVerdict.Mapping] with{RequestedTopology=batchVerdict.Topology};
        return new(point,bestMapping,suitableTopologies.Length,suitableTopologies,ordered,blockerText,batchRequest);
    }

    public string BuildMatrixText(IReadOnlyList<SignalConversionRangeEvaluation>? evaluations=null)
    {
        evaluations??=EvaluateAll();
        var text=new StringBuilder();
        text.AppendLine(string.Join('\t',
            "PointId","Name","Shape","InputMinA","InputMaxA","PeakA","Ratio","BestMapping","SuitableCount","SuitableTopologies",
            "BasicTia","BiasedTia","MultiRangeTia","LowSideShuntAmplifier","HighSideShuntAmplifier","Blocker"));
        foreach(var evaluation in evaluations)
        {
            var verdicts=evaluation.Verdicts.ToDictionary(verdict=>verdict.Topology);
            text.AppendLine(string.Join('\t',
                evaluation.Point.Index.ToString(CultureInfo.InvariantCulture),
                evaluation.Point.Name,
                evaluation.Point.Shape,
                Number(evaluation.Point.InputMinimum),
                Number(evaluation.Point.InputMaximum),
                Number(evaluation.Point.PeakMagnitude),
                RatioText(evaluation.Point.Ratio),
                evaluation.BestMapping,
                evaluation.SuitableCount.ToString(CultureInfo.InvariantCulture),
                evaluation.SuitableTopologies.Count==0?"none":string.Join("|",evaluation.SuitableTopologies.Select(SignalConversionDesignEngine.Name)),
                Verdict(verdicts,SignalConversionTopology.BasicTia),
                Verdict(verdicts,SignalConversionTopology.BiasedTia),
                Verdict(verdicts,SignalConversionTopology.MultiRangeTia),
                Verdict(verdicts,SignalConversionTopology.LowSideShuntAmplifier),
                Verdict(verdicts,SignalConversionTopology.HighSideShuntAmplifier),
                Clean(evaluation.Blocker)));
        }
        return text.ToString();
    }

    public string BuildBatchTestPointsText(IReadOnlyList<SignalConversionRangeEvaluation>? evaluations=null)
    {
        evaluations??=EvaluateAll();
        var service=new SignalConversionManualTestRowService();
        var inputHeader=string.Join('\t',SignalConversionManualTestRowService.Header
            .Split('\t').Take(SignalConversionManualTestRowService.InputColumnCount));
        var text=new StringBuilder(inputHeader).AppendLine();
        foreach(var evaluation in evaluations)
        {
            var point=evaluation.Point;
            text.AppendLine(service.SerializeRow(point.Index,$"{point.Name}_{evaluation.BestMapping}",evaluation.BestRequest));
        }
        return text.ToString();
    }

    public string BuildSummaryMarkdown(IReadOnlyList<SignalConversionRangeEvaluation>? evaluations=null)
    {
        evaluations??=EvaluateAll();
        var total=evaluations.Count;
        var histogram=Enumerable.Range(0,6).Select(count=>$"| {count} | {evaluations.Count(evaluation=>evaluation.SuitableCount==count)} |").ToArray();
        var topologyRows=Enum.GetValues<SignalConversionTopology>().Select(topology=>
        {
            var count=evaluations.Count(evaluation=>evaluation.SuitableTopologies.Contains(topology));
            return $"| {SignalConversionDesignEngine.Name(topology)} | {count} | {count*100.0/total:0.0}% |";
        }).ToArray();
        var blockerRows=evaluations.Where(evaluation=>evaluation.SuitableCount==0)
            .Select(evaluation=>BlockClass(evaluation.Blocker)).GroupBy(value=>value)
            .OrderByDescending(group=>group.Count()).Take(10)
            .Select(group=>$"| {group.Key} | {group.Count()} |").ToArray();
        var samples=evaluations.Where(evaluation=>evaluation.SuitableCount>0)
            .GroupBy(evaluation=>(int)Math.Floor(Math.Log10(evaluation.Point.PeakMagnitude)))
            .OrderBy(group=>group.Key).Take(13)
            .Select(group=>group.OrderByDescending(evaluation=>evaluation.SuitableCount).First())
            .Select(evaluation=>$"| {evaluation.Point.Name} | {Number(evaluation.Point.InputMinimum)} … {Number(evaluation.Point.InputMaximum)} | {evaluation.SuitableCount} | {string.Join(", ",evaluation.SuitableTopologies.Select(SignalConversionDesignEngine.Name))} |")
            .ToArray();
        var zeroByShape=evaluations.Where(evaluation=>evaluation.SuitableCount==0).GroupBy(evaluation=>evaluation.Point.Shape)
            .OrderByDescending(group=>group.Count()).Select(group=>$"| {group.Key} | {group.Count()} |").ToArray();
        var zeroByDecade=evaluations.Where(evaluation=>evaluation.SuitableCount==0)
            .GroupBy(evaluation=>(int)Math.Floor(Math.Log10(evaluation.Point.PeakMagnitude)))
            .OrderBy(group=>group.Key)
            .Select(group=>$"| {Number(Math.Pow(10,group.Key))} … {Number(Math.Pow(10,group.Key+1))} A | {group.Count()} |").ToArray();
        var commonCases=new (string Name,double Minimum,double Maximum,double Low,double High)[]
        {
            ("0…100 µA → 3.3…0 V（UI 默认）",0,100e-6,3.3,0),
            ("0…1 mA → 0…5 V",0,1e-3,0,5),
            ("0…10 µA → 0…5 V",0,10e-6,0,5),
            ("0…20 mA → 0…5 V",0,20e-3,0,5),
            ("4…20 mA → 1…5 V",4e-3,20e-3,1,5),
            ("0…1 A → 0…5 V",0,1,0,5),
            ("1…10 mA → 0.5…5 V",1e-3,10e-3,.5,5)
        };
        var commonRows=commonCases.Select(item=>
        {
            var request=Request(new(0,"common","common",item.Minimum,item.Maximum),item.Low,item.High);
            var suitable=engine.EvaluateCandidates(request).Where(candidate=>candidate.IsSelectable)
                .Select(candidate=>SignalConversionDesignEngine.Name(candidate.Topology)).ToArray();
            return $"| {item.Name} | {suitable.Length} | {(suitable.Length==0?"none":string.Join(", ",suitable))} |";
        }).ToArray();
        var b=new StringBuilder();
        b.AppendLine("# I/V 500 点输入范围矩阵（拓扑适配数）").AppendLine()
            .AppendLine("## 方法").AppendLine()
            .AppendLine($"- 500 个互不相同的输入电流范围（{Number(1e-12)} … {Number(1)} A），覆盖正/负同号、双极性、过零、零基、对称和偏置形状。")
            .AppendLine($"- 固定工程假设：单电源 VEE={Number(SupplyLowVoltage)} V / VCC={Number(SupplyHighVoltage)} V，运放共模 0…5 V，目标精度 {TargetAccuracyPercent}%（默认按满量程结算；若在高级选项中显式给出最小有效电流，则按该电流结算），目标带宽 {Number(TargetBandwidthHz)} Hz，E96，负载 1 MΩ，输入+传感器电容 50 pF，Burden ≤ 100 mV，Shunt 功耗 ≤ 0.5 W，其余为模块默认抽象运放参数。")
            .AppendLine("- 每个范围用两种自然映射评估：反相满摆幅（VCC→VEE，TIA 家族）和非反相满摆幅（VEE→VCC，Shunt 家族）；同号范围再加零参考映射。")
            .AppendLine("- 一个拓扑只要在任一映射下为 `FullyFeasible` 或 `ConditionallyFeasible` 就计为“合适”。因此计数回答的是“这个电流范围能不能被该拓扑实现”，而不是某一次固定端点映射的结果。")
            .AppendLine().AppendLine("## 结果分布").AppendLine()
            .AppendLine("| 合适拓扑数 | 范围数 |").AppendLine("| ---: | ---: |").AppendLine(string.Join(Environment.NewLine,histogram))
            .AppendLine().AppendLine($"- 至少 1 种拓扑可用：{evaluations.Count(evaluation=>evaluation.SuitableCount>0)} / {total}（{evaluations.Count(evaluation=>evaluation.SuitableCount>0)*100.0/total:0.0}%）。")
            .AppendLine($"- 完全没有可用拓扑：{evaluations.Count(evaluation=>evaluation.SuitableCount==0)} / {total}（{evaluations.Count(evaluation=>evaluation.SuitableCount==0)*100.0/total:0.0}%）。")
            .AppendLine().AppendLine("## 常见映射检查").AppendLine()
            .AppendLine("| 映射 | 合适数 | 合适拓扑 |").AppendLine("| --- | ---: | --- |").AppendLine(string.Join(Environment.NewLine,commonRows))
            .AppendLine().AppendLine("## 各拓扑可用范围数").AppendLine()
            .AppendLine("| 拓扑 | 可用范围数 | 占比 |").AppendLine("| --- | ---: | ---: |").AppendLine(string.Join(Environment.NewLine,topologyRows))
            .AppendLine().AppendLine("## 主要阻塞原因（按首条约束归类）").AppendLine()
            .AppendLine("| 阻塞类别 | 范围数 |").AppendLine("| --- | ---: |").AppendLine(string.Join(Environment.NewLine,blockerRows))
            .AppendLine().AppendLine("## 零可用范围按形状").AppendLine()
            .AppendLine("| 形状 | 范围数 |").AppendLine("| --- | ---: |").AppendLine(string.Join(Environment.NewLine,zeroByShape))
            .AppendLine().AppendLine("## 零可用范围按峰值数量级").AppendLine()
            .AppendLine("| 峰值区间 | 范围数 |").AppendLine("| --- | ---: |").AppendLine(string.Join(Environment.NewLine,zeroByDecade))
            .AppendLine().AppendLine("## 每个数量级一个可用样例").AppendLine()
            .AppendLine("| 测试点 | 输入范围 | 合适数 | 合适拓扑 |").AppendLine("| --- | --- | ---: | --- |").AppendLine(string.Join(Environment.NewLine,samples))
            .AppendLine().AppendLine("## 读法").AppendLine()
            .AppendLine("1. 计数为 0 只表示在**上述固定假设**下没有拓扑能同时满足极性、参考可生成、端点/误差预算、带宽和器件能力；不代表模块崩溃。")
            .AppendLine("2. 误差预算默认按满量程电流结算（“目标精度 1%”= 满量程的 1%）。若在高级选项里显式给出最小有效电流，则改为按该电流结算，会严格得多。")
            .AppendLine("3. 剩余 0 的主要来源是带宽：pA/nA 满量程需要极大的 Rf，与 10 kHz 带宽、55 pF 输入电容和 10 MHz GBW 物理冲突。降低带宽或改善器件参数即可进入可行区。")
            .AppendLine("4. 正电流的 TIA 需要负斜率或负参考；单电源 0…5 V 下 1…10 mA → 0…5 V 这类带负截距的映射在五种拓扑里没有可实现的参考，计数为 0 是正确的（改成 0.5…5 V 即可）。")
            .AppendLine("5. 每行的第一个阻塞原因在矩阵文件的 `Blocker` 列；逐拓扑结论在五列 `topology@mapping` 中。")
            .AppendLine().AppendLine("## 文件").AppendLine()
            .AppendLine("- `IV_500_INPUT_RANGE_TEST_POINTS.txt`：33 列批处理输入，可直接用 Batch Test 对话框加载（每行采用该范围最宽松的映射）。")
            .AppendLine("- `IV_500_INPUT_RANGE_MATRIX.txt`：500 行完整矩阵（含每拓扑结论与阻塞原因）。")
            .AppendLine("- `IV_500_INPUT_RANGE_SUMMARY.md`：本文件。");
        return b.ToString();
    }

    private static IReadOnlyList<(string Label,double Minimum,double Maximum)> Mappings(SignalConversionRangePoint point)
    {
        var mappings=new List<(string,double,double)>
        {
            ("inverting-full",SupplyHighVoltage,SupplyLowVoltage),
            ("non-inverting-full",SupplyLowVoltage,SupplyHighVoltage)
        };
        var peak=Math.Max(point.PeakMagnitude,1e-30);
        if(point.InputMaximum<=0)
        {
            var scale=SupplyHighVoltage/peak;
            mappings.Add(("zero-referenced-inverting",-scale*point.InputMinimum,-scale*point.InputMaximum));
        }
        if(point.InputMinimum>=0)
        {
            var scale=SupplyHighVoltage/peak;
            mappings.Add(("zero-referenced-non-inverting",scale*point.InputMinimum,scale*point.InputMaximum));
        }
        return mappings;
    }

    private static SignalConversionDesignRequest Request(SignalConversionRangePoint point,double outputAtMinimum,double outputAtMaximum)=>new()
    {
        InputMinimum=point.InputMinimum,InputMaximum=point.InputMaximum,
        OutputAtInputMinimum=outputAtMinimum,OutputAtInputMaximum=outputAtMaximum,
        SupplyLowVoltage=SupplyLowVoltage,SupplyHighVoltage=SupplyHighVoltage,
        OpAmpInputCommonModeMinimumVoltage=0,OpAmpInputCommonModeMaximumVoltage=5,
        TargetBandwidthHz=TargetBandwidthHz,TargetAccuracyPercent=TargetAccuracyPercent,
        OutputLoadResistanceOhm=1e6,InputAndSensorCapacitanceFarad=50e-12
    };

    private static (double Minimum,double Maximum,string Name) Shape(int shape,double peak,double ratio)
    {
        var small=ratio<=0?peak:peak/ratio;
        return shape switch
        {
            0=>(small,peak,"positive"),
            1=>(-peak,-small,"negative"),
            2=>(-small,peak,"bipolar-positive"),
            3=>(-peak,small,"bipolar-negative"),
            16=>(0,peak,"zero-based"),
            17=>(-peak,peak,"symmetric"),
            18=>(-peak/300,peak/300,"symmetric-small"),
            _=>(peak/2,peak,"offset")
        };
    }

    private static int Rank(CandidateFeasibility feasibility)=>feasibility switch
    {
        CandidateFeasibility.FullyFeasible=>0,
        CandidateFeasibility.ConditionallyFeasible=>1,
        CandidateFeasibility.NotVerified=>2,
        CandidateFeasibility.Infeasible=>3,
        _=>4
    };

    private static string BlockReason(SignalConversionCandidate candidate)=>
        candidate.Constraints.FirstOrDefault()??candidate.Reasons.FirstOrDefault()??"No reason reported.";

    private static string BlockClass(string blocker) => blocker switch
    {
        _ when blocker.Contains("error budget",StringComparison.OrdinalIgnoreCase)=> "误差预算超限（最小电流处）",
        _ when blocker.Contains("VREF",StringComparison.OrdinalIgnoreCase)||blocker.Contains("reference",StringComparison.OrdinalIgnoreCase)=> "参考电压无法由供电轨生成",
        _ when blocker.Contains("bandwidth",StringComparison.OrdinalIgnoreCase)=> "带宽不足",
        _ when blocker.Contains("output-swing",StringComparison.OrdinalIgnoreCase)||blocker.Contains("supply rails",StringComparison.OrdinalIgnoreCase)=> "输出端点超出供电轨",
        _ when blocker.Contains("polarity",StringComparison.OrdinalIgnoreCase)||blocker.Contains("slope",StringComparison.OrdinalIgnoreCase)=> "极性/斜率不匹配",
        _ when blocker.Contains("shunt",StringComparison.OrdinalIgnoreCase)=> "Shunt 负担/功耗/共模限制",
        _ when blocker.Contains("output-load current",StringComparison.OrdinalIgnoreCase)||blocker.Contains("output-current",StringComparison.OrdinalIgnoreCase)=> "运放输出电流不足",
        _ => "其它"
    };

    private static string Verdict(IReadOnlyDictionary<SignalConversionTopology,SignalConversionRangeVerdict> verdicts,SignalConversionTopology topology)=>
        verdicts.TryGetValue(topology,out var verdict)?$"{Label(verdict.Feasibility)}@{verdict.Mapping}":"none";

    private static string Label(CandidateFeasibility feasibility)=>feasibility switch
    {
        CandidateFeasibility.FullyFeasible=>"feasible",
        CandidateFeasibility.ConditionallyFeasible=>"conditional",
        CandidateFeasibility.NotSuitable=>"not-suitable",
        CandidateFeasibility.Infeasible=>"infeasible",
        _=>"not-verified"
    };

    private static string RatioText(double ratio)=>double.IsInfinity(ratio)?"inf":Number(ratio);
    private static string Number(double value)=>value.ToString("G9",CultureInfo.InvariantCulture);
    private static string Clean(string value)=>value.Replace('\t',' ').Replace('\r',' ').Replace('\n',' ').Trim();
}
