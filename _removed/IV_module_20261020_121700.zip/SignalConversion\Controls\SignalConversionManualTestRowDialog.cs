using CircuitModuleDesigner.Modules.SignalConversion.Engines;
using CircuitModuleDesigner.Modules.SignalConversion.Services;

namespace CircuitModuleDesigner.Modules.SignalConversion.Controls;

public sealed class SignalConversionManualTestRowDialog:Form
{
    private readonly RichTextBox input=Editor();
    private readonly RichTextBox output=Editor(true);
    private readonly Label status=new(){AutoSize=true,ForeColor=Color.DimGray,Margin=new Padding(8,8,8,0)};
    private readonly Button run=new(){Text="Run Rows",AutoSize=true,MinimumSize=new Size(100,28)};
    private readonly Button copy=new(){Text="Copy Results",AutoSize=true,MinimumSize=new Size(110,28),Enabled=false};
    private readonly Button copyWithHeader=new(){Text="Copy Header + Results",AutoSize=true,MinimumSize=new Size(160,28),Enabled=false};

    public SignalConversionManualTestRowDialog()
    {
        Text="I/V Conversion - Manual Batch Test";StartPosition=FormStartPosition.CenterParent;ClientSize=new Size(1180,620);MinimumSize=new Size(880,480);Font=new Font("Segoe UI",9F);
        var actions=new FlowLayoutPanel{Dock=DockStyle.Fill,AutoSize=true,WrapContents=false,Padding=new Padding(6,4,6,4)};
        var builtIn=new Button{Text="Load Built-in 70",AutoSize=true,MinimumSize=new Size(125,28)};
        var paste=new Button{Text="Paste Test Points",AutoSize=true,MinimumSize=new Size(125,28)};
        var load=new Button{Text="Load TXT...",AutoSize=true,MinimumSize=new Size(95,28)};
        var close=new Button{Text="Close",AutoSize=true,MinimumSize=new Size(75,28)};
        builtIn.Click+=(_,_)=>input.Text=new SignalConversionManualTestRowService().CreateBuiltIn70PointText();
        paste.Click+=(_,_)=>{if(Clipboard.ContainsText())input.Text=Clipboard.GetText().Trim();};
        load.Click+=(_,_)=>LoadTxt();run.Click+=async(_,_)=>await RunAsync();copy.Click+=(_,_)=>Copy(false);copyWithHeader.Click+=(_,_)=>Copy(true);close.Click+=(_,_)=>Close();
        actions.Controls.Add(builtIn);actions.Controls.Add(paste);actions.Controls.Add(load);actions.Controls.Add(run);actions.Controls.Add(copy);actions.Controls.Add(copyWithHeader);actions.Controls.Add(close);actions.Controls.Add(status);
        var root=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=5,Padding=new Padding(8)};
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));root.RowStyles.Add(new RowStyle(SizeType.Percent,42));root.RowStyles.Add(new RowStyle(SizeType.AutoSize));root.RowStyles.Add(new RowStyle(SizeType.Percent,58));root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        root.Controls.Add(new Label{Text=$"Input: tab-separated I/V test points. Header is optional. Maximum {SignalConversionManualTestRowService.MaximumBatchRows} rows.",AutoSize=true},0,0);root.Controls.Add(input,0,1);
        root.Controls.Add(new Label{Text="Output: production design result for the explicitly selected topology, comparison status for the other four topologies, and CircuitGraph verification for every input row.",AutoSize=true,Margin=new Padding(0,8,0,2)},0,2);
        root.Controls.Add(output,0,3);root.Controls.Add(actions,0,4);Controls.Add(root);
    }

    private void LoadTxt()
    {
        using var dialog=new OpenFileDialog{Filter="Text/TSV files (*.txt;*.tsv)|*.txt;*.tsv|All files (*.*)|*.*",Title="Load I/V test points"};
        if(dialog.ShowDialog(this)==DialogResult.OK)input.Text=File.ReadAllText(dialog.FileName);
    }

    private async Task RunAsync()
    {
        run.Enabled=false;copy.Enabled=copyWithHeader.Enabled=false;UseWaitCursor=true;status.ForeColor=Color.DimGray;status.Text="Parsing rows...";
        try
        {
            var service=new SignalConversionManualTestRowService();var rows=service.ParseMany(input.Text);
            var progress=new Progress<int>(count=>status.Text=$"Designing {count}/{rows.Count}...");
            var completed=await Task.Run(() =>
            {
                var engine=new SignalConversionDesignEngine();var batch=new List<(string Row,bool Generated)>(rows.Count);
                for(var index=0;index<rows.Count;index++)
                {
                    var result=engine.Design(rows[index].Request);
                    var evaluations=service.EvaluateTopologies(rows[index].Request,engine);
                    batch.Add((service.Complete(rows[index],result,evaluations),result.Success));
                    if((index+1)%10==0||index+1==rows.Count)((IProgress<int>)progress).Report(index+1);
                }
                return batch;
            });
            output.Lines=completed.Select(item=>item.Row).ToArray();copy.Enabled=copyWithHeader.Enabled=true;
            var generated=completed.Count(item=>item.Generated);status.ForeColor=generated==completed.Count?Color.DarkGreen:Color.DarkOrange;
            status.Text=$"Completed {completed.Count}: {generated} designs generated, {completed.Count-generated} correctly rejected or unresolved. Inspect Feasibility and Verification; completion is not a simulation PASS.";
        }
        catch(Exception exception){status.ForeColor=Color.Firebrick;status.Text=exception.Message;}
        finally{run.Enabled=true;UseWaitCursor=false;}
    }

    private void Copy(bool includeHeader)
    {
        if(output.TextLength==0)return;Clipboard.SetText(includeHeader?SignalConversionManualTestRowService.Header+Environment.NewLine+output.Text.Trim():output.Text.Trim());
    }

    private static RichTextBox Editor(bool readOnly=false)=>new(){Dock=DockStyle.Fill,ReadOnly=readOnly,WordWrap=false,DetectUrls=false,MaxLength=10_000_000,Font=new Font("Consolas",9F),BackColor=SystemColors.Window};
}
