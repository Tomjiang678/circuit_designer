using CircuitModuleDesigner.Core.Circuit;
using CircuitModuleDesigner.Core.Schematic;
using CircuitModuleDesigner.Core.Schematic.Symbols;
using CircuitModuleDesigner.Modules.SignalConversion.Engines;
using CircuitModuleDesigner.Modules.SignalConversion.Models;

namespace CircuitModuleDesigner.Modules.SignalConversion.Schematic;

public sealed class SignalConversionSchematicLayoutService
{
    public SchematicDocument Layout(CircuitGraph graph,SignalConversionCandidate candidate)
    {
        ArgumentNullException.ThrowIfNull(graph);ArgumentNullException.ThrowIfNull(candidate);
        if(candidate.Topology is SignalConversionTopology.BasicTia or SignalConversionTopology.BiasedTia or SignalConversionTopology.MultiRangeTia)
            return LayoutTia(graph,candidate);
        var document=new SchematicDocument(graph);var placed=new Dictionary<string,PlacedComponent>(StringComparer.OrdinalIgnoreCase);
        foreach(var component in graph.Components)Put(component,Position(component,graph,candidate),Orientation(component,candidate));
        foreach(var net in graph.Nets)Route(net);
        return document;

        void Put(CircuitComponent component,SchematicPoint point,ComponentOrientation orientation)
        {var item=new PlacedComponent(component,point,orientation);placed.Add(component.Reference,item);document.AddPlacedComponent(item);}
        SchematicPoint Pin(ComponentPin pin)=>SchematicGeometry.GetWorldPin(placed[pin.ComponentReference],pin.Name);
        void Route(CircuitNet net)
        {
            var pins=net.Pins.Select(Pin).ToArray();if(pins.Length==0)return;
            if(net.Name is "VCC" or "VEE" or "GND" or "VREF"||pins.Length==1)
            {
                foreach(var pin in net.Pins)
                {
                    var start=Pin(pin);var direction=SchematicGeometry.GetWorldPinDirection(placed[pin.ComponentReference],pin.Name);
                    var end=direction switch{SymbolPinDirection.Left=>new(start.X-55,start.Y),SymbolPinDirection.Right=>new(start.X+55,start.Y),SymbolPinDirection.Up=>new(start.X,start.Y-45),_=>new SchematicPoint(start.X,start.Y+45)};
                    document.AddWire(new(net.Name,[start,end]));document.AddNetLabel(new(net.Name,net.Name,end));
                }
                return;
            }
            if(net.Name=="IOUT")
            {
                var outputHub=new SchematicPoint(pins.Max(point=>point.X)+55,pins.Average(point=>point.Y));
                foreach(var pin in pins)document.AddWire(new(net.Name,[pin,new(outputHub.X,pin.Y),outputHub]));
                document.AddJunction(new(net.Name,outputHub));
                var terminal=new SchematicPoint(outputHub.X+70,outputHub.Y);
                document.AddWire(new(net.Name,[outputHub,terminal]));document.AddNetLabel(new(net.Name,net.Name,terminal));
                return;
            }
            if(pins.Length==2)
            {
                var a=pins[0];var z=pins[1];var middle=(a.X+z.X)/2;document.AddWire(new(net.Name,[a,new(middle,a.Y),new(middle,z.Y),z]));return;
            }
            var hub=new SchematicPoint(pins.Average(point=>point.X),pins.Average(point=>point.Y));
            foreach(var pin in pins)document.AddWire(new(net.Name,[pin,new(hub.X,pin.Y),hub]));document.AddJunction(new(net.Name,hub));
        }
    }

    private static SchematicDocument LayoutTia(CircuitGraph graph,SignalConversionCandidate candidate)
    {
        var document=new SchematicDocument(graph);
        var placed=new Dictionary<string,PlacedComponent>(StringComparer.OrdinalIgnoreCase);
        var ranges=Math.Max(1,candidate.RangeCount);
        var opAmpY=300+ranges*170;
        Put("U1",720,opAmpY);
        var summingX=315d;
        var feedbackX=475d;
        var rangeRightX=565d;
        var switchX=665d;
        var outputBusX=845d;
        var branchCenters=new List<(double ResistorY,double CapacitorY,double SwitchY,string Suffix)>();
        for(var index=0;index<ranges;index++)
        {
            var suffix=ranges==1?string.Empty:(index+1).ToString();
            var resistorY=95+index*200;
            var capacitorY=resistorY+100;
            var switchY=resistorY+50;
            Put("RF"+suffix,feedbackX,resistorY);
            Put("CF"+suffix,feedbackX,capacitorY);
            if(ranges>1)Put("SW"+(index+1),switchX,switchY);
            branchCenters.Add((resistorY,capacitorY,switchY,suffix));
        }
        var hasSafety=graph.Components.Any(component=>component.Reference.Equals("RSAFE",StringComparison.OrdinalIgnoreCase));
        if(hasSafety)
        {
            var safeY=95+ranges*200;
            Put("RSAFE",feedbackX,safeY);Put("CSAFE",feedbackX,safeY+100);
            branchCenters.Add((safeY,safeY+100,safeY+50,"SAFE"));
        }
        var hasReferenceDivider=graph.Components.Any(component=>component.Reference.Equals("RVT",StringComparison.OrdinalIgnoreCase));
        var hasReferenceBuffer=graph.Components.Any(component=>component.Reference.Equals("UREF",StringComparison.OrdinalIgnoreCase));
        if(hasReferenceDivider)
        {
            // Keep the buffered reference outside the op-amp/output-bus region for
            // both single-range and tall multi-range drawings.
            var referenceX=1040d;
            Put("RVT",referenceX,opAmpY-145,ComponentOrientation.Down);
            Put("RVB",referenceX,opAmpY+75,ComponentOrientation.Down);
            if(hasReferenceBuffer)Put("UREF",referenceX+220,opAmpY-35);
        }

        var u=placed["U1"];
        var minus=Pin("U1","IN-");
        var plus=Pin("U1","IN+");
        var output=Pin("U1","OUT");
        var topY=branchCenters[0].ResistorY;
        var bottomY=Math.Max(minus.Y,branchCenters[^1].CapacitorY);
        Wire("IIN",new(summingX,topY),new(summingX,bottomY));
        Wire("IIN",new(175,minus.Y),new(summingX,minus.Y));
        Label("IIN",new(175,minus.Y));
        Wire("IIN",new(summingX,minus.Y),minus);
        Junction("IIN",new(summingX,minus.Y));

        var outputTop=Math.Min(output.Y,branchCenters.Min(branch=>branch.SwitchY));
        var outputBottom=Math.Max(output.Y,branchCenters.Max(branch=>branch.SwitchY));
        Wire("VOUT",new(outputBusX,outputTop),new(outputBusX,outputBottom));
        Wire("VOUT",output,new(outputBusX,output.Y),new(925,output.Y));
        Junction("VOUT",new(outputBusX,output.Y));
        Label("VOUT",new(925,output.Y));
        foreach(var (resistorY,capacitorY,switchY,suffix) in branchCenters)
        {
            var safety=suffix=="SAFE";var resistorReference=safety?"RSAFE":"RF"+suffix;var capacitorReference=safety?"CSAFE":"CF"+suffix;
            var rfLeft=Pin(resistorReference,"1");var rfRight=Pin(resistorReference,"2");
            var cfLeft=Pin(capacitorReference,"1");var cfRight=Pin(capacitorReference,"2");
            Wire("IIN",new(summingX,resistorY),rfLeft);Wire("IIN",new(summingX,capacitorY),cfLeft);
            Junction("IIN",new(summingX,resistorY));Junction("IIN",new(summingX,capacitorY));
            var rangeNet=ranges==1||safety?"VOUT":"NRANGE"+suffix;
            Wire(rangeNet,rfRight,new(rangeRightX,resistorY),new(rangeRightX,capacitorY),cfRight);
            if(ranges==1||safety)
            {
                Wire("VOUT",new(rangeRightX,switchY),new(outputBusX,switchY));
                Junction("VOUT",new(outputBusX,switchY));
            }
            else
            {
                var swA=Pin("SW"+suffix,"A");var swB=Pin("SW"+suffix,"B");var control=Pin("SW"+suffix,"CTRL");
                Wire(rangeNet,new(rangeRightX,switchY),swA);
                Wire("VOUT",swB,new(outputBusX,switchY));
                Junction("VOUT",new(outputBusX,switchY));
                var controlEnd=new SchematicPoint(control.X,control.Y+58);
                Wire("GAIN"+suffix,control,controlEnd);Label("GAIN"+suffix,controlEnd);
            }
        }

        var lowRail=graph.GetNetForPin("U1","V-")?.Name??"VEE";
        if(hasReferenceDivider)
        {
            var dividerTop=Pin("RVT","2");
            var dividerBottom=Pin("RVB","1");
            if(hasReferenceBuffer)
            {
                var bufferPlus=Pin("UREF","IN+");var bufferMinus=Pin("UREF","IN-");var bufferOut=Pin("UREF","OUT");
                Wire("VREF_RAW",dividerTop,dividerBottom,new(dividerTop.X,bufferPlus.Y),bufferPlus);
                Wire("VREF",bufferOut,new(bufferOut.X,bufferMinus.Y),bufferMinus);
                Wire("VREF",bufferOut,new(bufferOut.X,plus.Y),plus);Junction("VREF",bufferOut);
                Stub("VCC",Pin("UREF","V+"),45);Stub(lowRail,Pin("UREF","V-"),45);
            }
            else
            {
                var referenceBranch=new SchematicPoint(dividerTop.X,plus.Y);
                Wire("VREF",dividerTop,dividerBottom);Wire("VREF",referenceBranch,plus);Junction("VREF",referenceBranch);
            }
            Stub("VCC",Pin("RVT","1"),48);
            Stub(lowRail,Pin("RVB","2"),48);
        }
        else Stub("GND",plus,70);
        Stub("VCC",Pin("U1","V+"),52);
        Stub(lowRail,Pin("U1","V-"),52);
        return document;

        void Put(string reference,double x,double y,ComponentOrientation orientation=ComponentOrientation.Right)
        {
            var item=new PlacedComponent(graph.GetComponent(reference),new(x,y),orientation);
            placed.Add(reference,item);document.AddPlacedComponent(item);
        }
        SchematicPoint Pin(string reference,string pin)=>SchematicGeometry.GetWorldPin(placed[reference],pin);
        void Wire(string net,params SchematicPoint[] points)=>document.AddWire(new(net,points));
        void Label(string net,SchematicPoint point)=>document.AddNetLabel(new(net,net,point));
        void Junction(string net,SchematicPoint point)=>document.AddJunction(new(net,point));
        void Stub(string net,SchematicPoint start,double length)
        {
            var pin=graph.GetNet(net).Pins.FirstOrDefault(item=>Pin(item.ComponentReference,item.Name)==start);
            var direction=pin is null?SymbolPinDirection.Left:SchematicGeometry.GetWorldPinDirection(placed[pin.ComponentReference],pin.Name);
            var end=direction switch{SymbolPinDirection.Up=>new(start.X,start.Y-length),SymbolPinDirection.Down=>new(start.X,start.Y+length),SymbolPinDirection.Right=>new(start.X+length,start.Y),_=>new SchematicPoint(start.X-length,start.Y)};
            Wire(net,start,end);Label(net,end);
        }
    }

    private static SchematicPoint Position(CircuitComponent component,CircuitGraph graph,SignalConversionCandidate candidate)
    {
        if(component.Reference=="U1")return new(650,350);
        if(component.Reference=="RVT")return new(980,150);
        if(component.Reference=="RVB")return new(980,320);
        if(component.Reference=="UREF")return new(800,235);
        if(component.Reference=="RSH")return new(145,350);
        if(component.Reference.StartsWith("SW",StringComparison.OrdinalIgnoreCase))return new(760,95+Numeric(component.Reference)*85);
        if(component.Reference.StartsWith("CF",StringComparison.OrdinalIgnoreCase))return new(465+Numeric(component.Reference)*100,205);
        if(component.Reference.StartsWith("RF",StringComparison.OrdinalIgnoreCase))return new(465+Numeric(component.Reference)*100,115);
        if(component.Reference is "R1")return new(280,250);
        if(component.Reference is "R2")return new(440,170);
        if(component.Reference is "R3")return new(440,510);
        if(component.Reference is "R4")return new(760,510);
        var index=graph.Components.ToList().IndexOf(component);return new(250+(index%4)*150,180+(index/4)*150);
    }

    private static ComponentOrientation Orientation(CircuitComponent component,SignalConversionCandidate candidate)=>
        component.Type==ComponentType.Resistor&&component.Reference=="RSH"?ComponentOrientation.Down:ComponentOrientation.Right;

    private static int Numeric(string reference)
    {
        var digits=new string(reference.Where(char.IsDigit).ToArray());return int.TryParse(digits,out var number)?number:0;
    }
}
