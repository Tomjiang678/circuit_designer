# I/V Conversion 工程设计说明

## 1. 模块边界

SignalConversion 现在只设计 Current-to-Voltage Converter。模块中不存在转换方向选择，也不包含 Improved Howland、MOSFET Current Sink/Source、Push-Pull、V/I Multi-Range 或其它 Voltage-to-Current 业务分支。

保留的五种实现为：

1. Basic TIA
2. Biased TIA
3. Programmable-Gain / Multi-Range TIA
4. Low-Side Shunt Amplifier
5. High-Side Shunt Amplifier

MOSFET 符号、CircuitGraph、SPICE 序列化器和标准元件工具仍是项目公共基础设施，不能因本模块取消 V/I 而删除。

## 2. 输入需求模型

用户明确给出两个端点：

- `InputMinimum` 与 `OutputAtInputMinimum`
- `InputMaximum` 与 `OutputAtInputMaximum`

因此需求不是两个互不关联的升序范围，而是严格映射：

```text
Ktarget = (Vout@Imax - Vout@Imin) / (Imax - Imin)
Btarget = Vout@Imin - Ktarget * Imin
Vout,target = Ktarget * Iin + Btarget
```

这样可以直接表达 `0…100 µA -> 3.3…0 V`。本模块约定 TIA 的正输入电流流入反相求和节点，所以 TIA 的实际斜率必须为负；Shunt 的正电流在采样电阻上产生正差分电压，所以当前差分放大实现的实际斜率为正。

除端点外，设计请求包含供电、带宽、精度、最小有效电流、输入/传感器电容、负载、允许 Burden Voltage、Shunt 功耗、是否保持负载接地，以及抽象运放和开关参数。没有具体器件型号时，这些参数是显式工程假设，不是器件保证值。

误差预算的基准电流默认取该范围的满量程电流：`目标精度 1%` 表示“满量程的 1%”。只有用户在高级选项里显式填写“精度参考电流/最小有效电流”时，偏置、漏电、失调和噪声才改为相对该电流结算（更严格）。输出端点只与 VEE/VCC 比较，不再存在任何隐藏的“输出余量”常数。

拓扑必须由用户在五种实现中明确选择（`RequestedTopology`）。请求中不再存在拓扑家族、测量位置或量程策略的 Auto 模式：这些属性由所选拓扑唯一决定（Low-Side/High-Side Shunt 决定位置，Multi-Range TIA 决定多量程，其它三种为单量程）。缺少显式拓扑时引擎直接拒绝，绝不会自动挑选或替换。

## 3. 统一设计与验证流程

每个候选都经过相同阶段：

1. 根据端点建立目标仿射映射。
2. 检查端点输出是否落在供电轨内（直接与 VEE/VCC 比较，不再使用任何“输出余量”常数）；超出时直接给出可操作的错误信息。
3. 按用户明确选择的拓扑求解理想元件值；其它四种拓扑只作为对照证据评估，不参与选择。
4. 量化到指定 E24/E48/E96 系列。
5. 使用量化后的元件重新计算实际传递函数、输出端点、误差、带宽、噪声和功耗。
6. 从同一候选模型生成 CircuitGraph。
7. 从 CircuitGraph 中重新读取真实连接和元件值，独立复算 DC 传递关系。
8. 标注解析验证、标准值验证、器件能力验证和 SPICE 状态。

不存在自动推荐算法。设计结果只使用 `RequestedTopology` 指向的候选：它可选取时才会生成电路，不可选取时返回该候选自身的原因，不会退回到其它拓扑。界面在每个选项旁显示该拓扑当前是“可行 / 基于声明参数可行 / 不可行”，因此用户可以在选择前看到后果。

候选状态为 `FullyFeasible`、`ConditionallyFeasible`、`NotSuitable`、`Infeasible` 或 `NotVerified`。`SupportedTopologies` 只包含前两类，并保留每个候选的具体保留或淘汰理由。

## 4. Basic TIA

### 电路

- 输入电流接运放反相节点 `IIN`
- 同相输入接 0 V
- `Rf || Cf` 从 `VOUT` 回到 `IIN`

理想 DC 关系：

```text
Vout = -Iin * Rf
```

因此 Basic TIA 只适合目标截距接近零的负斜率映射。`Rf` 量化后，系统以实际 `Rf` 重新检查两个端点，而不是继续显示目标直线。

`Cf` 的起始值同时考虑输入/传感器电容、运放输入电容、反馈寄生、GBW 和目标带宽；随后检查反馈极点、估算闭环带宽和噪声增益条件。解析估算不能替代真实环路增益仿真，所以相位裕度不会被虚构为 PASS。

误差预算分别记录反馈电阻容差、输入偏置、PCB 漏电、输入失调、反馈电阻热噪声、运放电压/电流噪声、积分噪声和端点误差，默认都以满量程电流（或用户显式给出的精度参考电流）为基准；pA/nA 设计另外检查偏置/漏电与最小有效信号的关系，并给出 Guard Ring、清洁度、绝缘与湿度相关警告。

## 5. Biased TIA

电路保留 `Rf || Cf` 反相反馈，但同相端连接真实缓冲参考 `VREF`：

```text
Vout = Vref - Iin * Rf
```

`Vref` 由目标端点和量化后的 `Rf` 反推，而不是把软件截距无条件当作一个理想标签。参考网络由 VCC/VEE 分压并经 `UREF` 缓冲；CircuitGraph 中包含分压电阻、缓冲器和真实连接。验证包括参考可生成范围、分压误差、加载、参考噪声和缓冲需求。

当负斜率目标需要非零零电流输出、单电源 ADC 电平偏移或双极性电流映射时，该拓扑通常优于 Basic TIA。

## 6. Multi-Range TIA

Multi-Range 使用一个运放和多组可切换的 `Rf || Cf` 支路。档位数不再按固定 1000:1 划分，而由最小有效电流、总动态范围、允许输出摆幅、目标精度、噪声下限和档位重叠共同决定。每档独立保存：

- 有效输入范围
- 标准值 `Rf`、`Cf`
- 实际跨阻和输出范围
- 估算带宽
- 噪声、偏置、漏电和开关误差

原理图同时显示全部档位支路和 GAIN 控制。除切换支路外，电路包含永久的 `RSAFE || CSAFE` 安全反馈，使 break-before-make 期间不会完全开环。结果仍明确要求工程切换顺序：抑制或保持输入、切换档位、等待建立、再恢复测量。

开关导通电阻、漏电、寄生电容和电荷注入属于实际误差/稳定性约束。没有选定模拟开关模型和 GAIN 状态时，多量程 SPICE 与切换瞬态均标为 `NOT VERIFIED`。

## 7. Low-Side Shunt Amplifier

采样电阻位于负载回流端。系统联合求解 `Rs` 与四电阻差分放大器增益：

```text
Vshunt = Iin * Rs
Vout = Vref,out + Gdiff * Vshunt
```

`Rs` 同时受允许 Burden Voltage、最大功耗、目标增益、运放失调误差和标准阻值限制。放大电阻量化后重新计算真实增益和输出偏置。误差预算包含 Shunt 容差、TCR/温升、差分电阻比例误差、运放失调、噪声和输出端点误差。

原理图使用 Kelvin 感测节点。若用户要求负载必须保持接地，Low-Side 会被判为 `NotSuitable`，而不是因为元件少就优先选择。

## 8. High-Side Shunt Amplifier

采样电阻位于电源和负载之间，负载可以保持接地。系统对实际四电阻差分网络求解两个运放输入引脚电压，不只检查一个母线标签。检查项目包括：

- Shunt 两端共模和差模电压
- 运放输入共模窗口
- 电阻网络引起的引脚电压
- 电阻匹配和 CMRR 导致的共模转差模误差
- 输出摆幅、带宽和负载
- Shunt 压降、功耗、TCR 和 Kelvin 连接

当声明的普通运放无法承受高侧共模时，该候选会被拒绝或标为条件可行，不会强行生成 Feasible。高侧 SPICE 需要完整母线/负载网络和所选高共模器件模型；缺少这些条件时诚实返回 `NOT VERIFIED`。

## 9. 拓扑选择与判定规则

- 五种拓扑由用户显式选择，没有 Auto、没有打分推荐、也没有替换。
- Basic TIA 只在所需参考为 0 V 时成立；需要非零截距时由 Biased TIA 承担。
- Multi-Range TIA 总是按多量程实现，量程数量由最小有效电流、噪声、精度和重叠决定（至少 2 段）。
- Low-Side Shunt 与 High-Side Shunt 各自固定测量位置；Low-Side 与“必须保持负载接地”互斥。
- 负斜率只会出现在 TIA 候选的可行说明中；正斜率只会出现在 Shunt 候选的可行说明中。
- TIA 必须通过输入电容、GBW、稳定性估算、偏置、漏电、输出摆幅和输出电流检查。
- Shunt 必须通过 Burden、功耗、失调、共模、差分网络、输出摆幅和带宽检查。
- 所选拓扑不可行时，结果页只陈述该拓扑的拒绝原因，并提示不会自动替换。

## 10. 测试与批处理

`IV_70_MANUAL_TEST_POINTS.txt` 是当前基线，严格包含：

- Basic TIA：15 条
- Biased TIA：15 条
- Multi-Range TIA：15 条
- Low-Side Shunt：15 条
- High-Side Shunt：10 条

批处理上限为 1000 条。每行输入用 `Topology` 列显式指定拓扑（`MultiRangePolicy`、`TopologyFamily`、`MeasurementLocation` 三列已删除）；每一行都调用生产设计引擎，并对五种拓扑分别输出状态与首要原因，作为对照证据而非自动推荐。界面使用“design generated / rejected or unresolved”，不会把生成成功冒充 SPICE PASS。

`IV_500_INPUT_RANGE_TEST_POINTS.txt`、`IV_500_INPUT_RANGE_MATRIX.txt`、`IV_500_INPUT_RANGE_SUMMARY.md` 是输入范围适配矩阵（`--iv-range-matrix <目录>` 可重新生成）：500 个互不相同的输入电流范围（1 pA…1 A，正/负同号、双极性、零基、对称、偏置），每个范围用反相满摆幅、非反相满摆幅以及同号范围的零参考映射分别评估，统计五种拓扑中有几种可行。矩阵文件逐行给出每种拓扑的结论与首个阻塞原因。

自动化边界测试还覆盖反向端点映射、pA 偏置/漏电、高侧共模、输出负载能力、永久安全反馈、CircuitGraph 独立复算、SPICE 诚实状态、500 点范围矩阵结构和 1000/1001 行边界。

## 11. 当前验证边界

当前已经具备目标映射、标准值参数、解析 DC、误差预算、部分带宽/噪声估算和 CircuitGraph 独立验证。仍然需要选定真实器件后才能完成：

- 运放厂商宏模型下的 DC/AC/噪声仿真
- TIA 环路增益和相位裕度签核
- Multi-Range 开关电荷注入与切换瞬态
- High-Side 完整母线/负载扫描和高共模器件验证
- 温升、PCB 漏电、绝缘和生产公差的实物确认

因此 UI 和导出结果必须区分“解析通过”“标准值通过”“器件能力基于声明参数”“网表已生成”和“SPICE 已执行通过”。未执行的验证保持 `NOT VERIFIED`。
