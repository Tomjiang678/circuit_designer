using CircuitModuleDesigner.Core.Circuit;
using CircuitModuleDesigner.Modules.SignalConversion.Models;

namespace CircuitModuleDesigner.Modules.SignalConversion.Schematic;

public sealed class SignalConversionCircuitFactory
{
    public CircuitGraph Build(SignalConversionCandidate candidate,SignalConversionDesignRequest? request=null)
    {
        ArgumentNullException.ThrowIfNull(candidate);
        return candidate.Topology switch
        {
            SignalConversionTopology.BasicTia or SignalConversionTopology.BiasedTia or SignalConversionTopology.MultiRangeTia=>BuildTia(candidate,request),
            SignalConversionTopology.LowSideShuntAmplifier or SignalConversionTopology.HighSideShuntAmplifier=>BuildShunt(candidate,request),
            _=>throw new NotSupportedException($"{candidate.Topology} is not an I/V topology.")
        };
    }

    private static CircuitGraph BuildTia(SignalConversionCandidate candidate,SignalConversionDesignRequest? request)
    {
        var b=new CircuitBuilder();var u=b.Add(ComponentFactory.OpAmp("U1"));
        var lowRail=request is not null&&Math.Abs(request.SupplyLowVoltage)<1e-12?"GND":"VEE";
        b.Connect("VCC",u.GetPin("V+"));b.Connect(lowRail,u.GetPin("V-"));
        if(candidate.Topology==SignalConversionTopology.BasicTia)b.Connect("GND",u.GetPin("IN+"));
        else b.Connect(AddReference(b,candidate,request,"RV","VREF","UREF"),u.GetPin("IN+"));
        var ranges=Math.Max(1,candidate.RangeCount);
        if(ranges>1)
        {
            var safeRf=b.Add(ComponentFactory.Resistor("RSAFE",Value(candidate,"RSAFE",1e9)));
            var safeCf=b.Add(ComponentFactory.Capacitor("CSAFE",Value(candidate,"CSAFE",1e-12)));
            b.Connect("IIN",u.GetPin("IN-"),safeRf.GetPin("1"),safeCf.GetPin("1"));
            b.Connect("VOUT",u.GetPin("OUT"),safeRf.GetPin("2"),safeCf.GetPin("2"));
        }
        for(var index=0;index<ranges;index++)
        {
            var suffix=ranges==1?string.Empty:(index+1).ToString();
            var rf=b.Add(ComponentFactory.Resistor("RF"+suffix,Value(candidate,"RF"+suffix,Value(candidate,"RF",10_000))));
            var cf=b.Add(ComponentFactory.Capacitor("CF"+suffix,Value(candidate,"CF"+suffix,Value(candidate,"CF",10e-12))));
            b.Connect("IIN",u.GetPin("IN-"),rf.GetPin("1"),cf.GetPin("1"));
            if(ranges==1)b.Connect("VOUT",u.GetPin("OUT"),rf.GetPin("2"),cf.GetPin("2"));
            else
            {
                var sw=b.Add(ComponentFactory.AnalogSwitch("SW"+(index+1),Value(candidate,"SW"+(index+1),10)));
                b.Connect("NRANGE"+(index+1),rf.GetPin("2"),cf.GetPin("2"),sw.GetPin("A"));
                b.Connect("VOUT",u.GetPin("OUT"),sw.GetPin("B"));
                b.Connect("GAIN"+(index+1),sw.GetPin("CTRL"));
            }
        }
        return b.Build();
    }

    private static CircuitGraph BuildShunt(SignalConversionCandidate candidate,SignalConversionDesignRequest? request)
    {
        var b=new CircuitBuilder();var u=b.Add(ComponentFactory.OpAmp("U1"));
        var shunt=b.Add(ComponentFactory.Resistor("RSH",Value(candidate,"RSH",.1)));
        var r1=b.Add(ComponentFactory.Resistor("R1",Value(candidate,"R1",10_000)));
        var r2=b.Add(ComponentFactory.Resistor("R2",Value(candidate,"R2",100_000)));
        var r3=b.Add(ComponentFactory.Resistor("R3",Value(candidate,"R3",10_000)));
        var r4=b.Add(ComponentFactory.Resistor("R4",Value(candidate,"R4",100_000)));
        var lowRail=request is not null&&Math.Abs(request.SupplyLowVoltage)<1e-12?"GND":"VEE";
        b.Connect("VCC",u.GetPin("V+"));b.Connect(lowRail,u.GetPin("V-"));
        var referenceNet=AddReference(b,candidate,request,"RV","VREF","UREF");
        if(candidate.Topology==SignalConversionTopology.LowSideShuntAmplifier)
        {
            b.Connect("IIN",shunt.GetPin("1"),r3.GetPin("1"));
            b.Connect("GND",shunt.GetPin("2"),r1.GetPin("1"));
        }
        else
        {
            b.Connect("IIN",shunt.GetPin("1"),r3.GetPin("1"));
            b.Connect("SENSE_LO",shunt.GetPin("2"),r1.GetPin("1"));
        }
        b.Connect("NMINUS",u.GetPin("IN-"),r1.GetPin("2"),r2.GetPin("1"));b.Connect("VOUT",u.GetPin("OUT"),r2.GetPin("2"));
        b.Connect("NPLUS",u.GetPin("IN+"),r3.GetPin("2"),r4.GetPin("1"));b.Connect(referenceNet,r4.GetPin("2"));
        return b.Build();
    }

    private static string AddReference(CircuitBuilder b,SignalConversionCandidate candidate,SignalConversionDesignRequest? request,
        string prefix,string outputNet,string bufferReference)
    {
        var top=candidate.Components.FirstOrDefault(component=>component.Reference.Equals(prefix+"T",StringComparison.OrdinalIgnoreCase));
        var bottom=candidate.Components.FirstOrDefault(component=>component.Reference.Equals(prefix+"B",StringComparison.OrdinalIgnoreCase));
        var lowRail=request is not null&&Math.Abs(request.SupplyLowVoltage)<1e-12?"GND":"VEE";
        if(top is null||bottom is null)
        {
            var requested=prefix=="RV"?candidate.ActualTransferOffset:0;
            if(request is not null&&Math.Abs(requested-request.SupplyHighVoltage)<1e-9)return "VCC";
            if(request is not null&&Math.Abs(requested-request.SupplyLowVoltage)<1e-9)return lowRail;
            if(Math.Abs(requested)<1e-9)return "GND";
            throw new InvalidOperationException($"Reference {requested:G9} V has no generated divider or matching supply rail.");
        }
        var upper=b.Add(ComponentFactory.Resistor(prefix+"T",top.Value));var lower=b.Add(ComponentFactory.Resistor(prefix+"B",bottom.Value));
        var buffered=candidate.Components.Any(component=>component.Reference.Equals(prefix+"BUF",StringComparison.OrdinalIgnoreCase));
        if(!buffered)
        {
            b.Connect("VCC",upper.GetPin("1"));b.Connect(outputNet,upper.GetPin("2"),lower.GetPin("1"));b.Connect(lowRail,lower.GetPin("2"));
            return outputNet;
        }
        var buffer=b.Add(ComponentFactory.OpAmp(bufferReference));var raw=outputNet+"_RAW";
        b.Connect("VCC",upper.GetPin("1"),buffer.GetPin("V+"));b.Connect(raw,upper.GetPin("2"),lower.GetPin("1"),buffer.GetPin("IN+"));
        b.Connect(lowRail,lower.GetPin("2"),buffer.GetPin("V-"));b.Connect(outputNet,buffer.GetPin("OUT"),buffer.GetPin("IN-"));
        return outputNet;
    }

    private static double Value(SignalConversionCandidate candidate,string reference,double fallback)=>
        candidate.Components.FirstOrDefault(component=>component.Reference.Equals(reference,StringComparison.OrdinalIgnoreCase))?.Value is >0 and var value?value:fallback;
}
