namespace CircuitModuleDesigner.Modules.SignalConversion.Models;

public enum SignalConversionPreferredSeries { E24, E48, E96 }
public enum EngineeringEvidenceLevel { IdealTheory, EstimatedFromAssumptions, VerifiedFromCircuit, SpiceVerified }
public enum VerificationOutcome { Pass, Fail, NotVerified }

/// <summary>
/// The complete and intentionally closed I/V topology set. The user always
/// selects one of these five entries explicitly; there is no automatic
/// topology selection, topology family, measurement-location or range-policy
/// mode any more. Each entry fully determines the family, shunt location and
/// range strategy.
/// </summary>
public enum SignalConversionTopology
{
    BasicTia,
    BiasedTia,
    MultiRangeTia,
    LowSideShuntAmplifier,
    HighSideShuntAmplifier
}

public enum CandidateFeasibility
{
    FullyFeasible,
    ConditionallyFeasible,
    NotSuitable,
    Infeasible,
    NotVerified
}

public readonly record struct SignalConversionAffineRequirement(double Slope,double Offset)
{
    public double Evaluate(double inputCurrent)=>Slope*inputCurrent+Offset;
}

/// <summary>
/// I/V endpoint mapping. OutputAtInputMinimum and OutputAtInputMaximum are not
/// sorted, so 0..100 uA can explicitly map to 3.3..0 V. Positive input current
/// is current entering the converter input.
/// </summary>
public static class SignalConversionTransferRequirement
{
    public static SignalConversionAffineRequirement For(SignalConversionDesignRequest request)
    {
        var slope=(request.OutputAtInputMaximum-request.OutputAtInputMinimum)/(request.InputMaximum-request.InputMinimum);
        return new(slope,request.OutputAtInputMinimum-slope*request.InputMinimum);
    }
}

public sealed record SignalConversionDesignRequest
{
    /// <summary>
    /// Topology chosen by the user. It is mandatory: <see cref="Engines.SignalConversionDesignEngine.Design"/>
    /// never falls back to another topology.
    /// </summary>
    public SignalConversionTopology? RequestedTopology { get; init; }

    public double InputMinimum { get; init; }
    public double InputMaximum { get; init; }=1e-3;
    public double OutputAtInputMinimum { get; init; }=3.3;
    public double OutputAtInputMaximum { get; init; }
    public double OutputWindowMinimum=>Math.Min(OutputAtInputMinimum,OutputAtInputMaximum);
    public double OutputWindowMaximum=>Math.Max(OutputAtInputMinimum,OutputAtInputMaximum);
    public double OutputSpan=>Math.Abs(OutputAtInputMaximum-OutputAtInputMinimum);

    public double SupplyHighVoltage { get; init; }=5;
    public double SupplyLowVoltage { get; init; }
    public double TargetBandwidthHz { get; init; }=10_000;
    public double TargetAccuracyPercent { get; init; }=1;
    public double MinimumResolvedInputMagnitude { get; init; }
    public double RangeOverlapPercent { get; init; }=10;
    public bool MustPreserveLoadGround { get; init; }

    public double InputAndSensorCapacitanceFarad { get; init; }=50e-12;
    public double FeedbackParasiticCapacitanceFarad { get; init; }=.2e-12;
    public double OutputLoadResistanceOhm { get; init; }=1_000_000;
    public double MaximumBurdenVoltage { get; init; }=.1;
    public double MaximumShuntPowerWatt { get; init; }=.5;
    public double HighSideCommonModeVoltage { get; init; }=5;
    public double ShuntResistanceTolerancePercent { get; init; }=.1;
    public double ShuntTcrPpmPerC { get; init; }=25;
    public double EstimatedShuntTemperatureRiseC { get; init; }=30;
    public double DifferenceAmplifierRatioMatchPercent { get; init; }=.05;

    public SignalConversionPreferredSeries PreferredSeries { get; init; }=SignalConversionPreferredSeries.E96;
    public bool QuantizeComponents { get; init; }=true;

    // Abstract device constraints. They remain assumptions until a real
    // part/model is selected; DeviceParametersVerified controls the label.
    public bool DeviceParametersVerified { get; init; }
    public double OpAmpGainBandwidthHz { get; init; }=10_000_000;
    public double OpAmpOutputCurrentAmpere { get; init; }=.02;
    public double OpAmpInputBiasCurrentAmpere { get; init; }=10e-12;
    public double OpAmpInputOffsetVoltage { get; init; }=50e-6;
    public double OpAmpVoltageNoiseVoltPerRootHz { get; init; }=8e-9;
    public double OpAmpCurrentNoiseAmperePerRootHz { get; init; }=1e-15;
    public double OpAmpInputCapacitanceFarad { get; init; }=5e-12;
    public double OpAmpInputCommonModeMinimumVoltage { get; init; }
    public double OpAmpInputCommonModeMaximumVoltage { get; init; }=5;
    public double OpAmpCommonModeRejectionDb { get; init; }=100;

    public double PcbLeakageCurrentAmpere { get; init; }=1e-12;
    public double AnalogSwitchLeakageAmpere { get; init; }=10e-12;
    public double AnalogSwitchOnResistanceOhm { get; init; }=10;
    public double AnalogSwitchParasiticCapacitanceFarad { get; init; }=5e-12;
    public double AnalogSwitchChargeInjectionCoulomb { get; init; }=5e-12;
}

public sealed record SignalConversionComponent(string Reference,string Role,double Value,string Unit,string? Note=null);
public sealed record SignalConversionErrorContribution(string Name,double Percent,VerificationOutcome Outcome,string Detail="");

public sealed record SignalConversionVerification(
    string Name,
    VerificationOutcome Outcome,
    double? Target=null,
    double? Actual=null,
    string Unit="",
    string Detail="");

public sealed record SignalConversionRangeDesign(
    string Name,
    double InputMinimum,
    double InputMaximum,
    double TargetSlope,
    double TargetOffset,
    double ActualSlope,
    double ActualOffset,
    double OutputMinimum,
    double OutputMaximum,
    double PredictedBandwidthHz,
    double PredictedNoiseRms,
    double PredictedErrorPercent,
    VerificationOutcome Outcome,
    string Note="");

public sealed record SignalConversionCandidate(
    SignalConversionTopology Topology,
    string Configuration,
    CandidateFeasibility Feasibility,
    IReadOnlyList<string> Reasons,
    IReadOnlyList<string> Constraints,
    IReadOnlyList<SignalConversionComponent> Components,
    double PredictedAccuracyPercent,
    double PredictedBandwidthHz,
    double PredictedPowerWatt,
    int RangeCount=1)
{
    public double ActualTransferSlope { get; init; }
    public double ActualTransferOffset { get; init; }
    public double MaximumTransferErrorPercent { get; init; }
    public EngineeringEvidenceLevel EvidenceLevel { get; init; }=EngineeringEvidenceLevel.IdealTheory;
    public IReadOnlyList<SignalConversionErrorContribution> ErrorBudget { get; init; }=[];
    public IReadOnlyList<SignalConversionVerification> Verification { get; init; }=[];
    public IReadOnlyList<SignalConversionRangeDesign> Ranges { get; init; }=[];
    public IReadOnlyList<string> Warnings { get; init; }=[];
    public bool IsSelectable=>Feasibility is CandidateFeasibility.FullyFeasible or CandidateFeasibility.ConditionallyFeasible;
}

public sealed record SignalConversionDesignResult
{
    public required SignalConversionDesignRequest Request { get; init; }
    public required IReadOnlyList<SignalConversionCandidate> Candidates { get; init; }
    public SignalConversionCandidate? Recommended { get; init; }
    public bool Success=>Recommended is not null;
    public string Message { get; init; }=string.Empty;
    public double TransferSlope { get; init; }
    public double TransferOffset { get; init; }
    public double ActualTransferSlope=>Recommended?.ActualTransferSlope??double.NaN;
    public double ActualTransferOffset=>Recommended?.ActualTransferOffset??double.NaN;
}
