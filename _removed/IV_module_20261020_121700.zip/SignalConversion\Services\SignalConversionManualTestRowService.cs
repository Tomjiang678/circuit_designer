using System.Globalization;
using CircuitModuleDesigner.Modules.SignalConversion.Engines;
using CircuitModuleDesigner.Modules.SignalConversion.Models;

namespace CircuitModuleDesigner.Modules.SignalConversion.Services;

public sealed record ParsedSignalConversionTestRow(string[] InputFields,char Delimiter,SignalConversionDesignRequest Request);
public sealed record SignalConversionTopologyEvaluation(SignalConversionTopology Topology,CandidateFeasibility Feasibility,IReadOnlyList<string> Reasons)
{
    public bool Supported=>Feasibility is CandidateFeasibility.FullyFeasible or CandidateFeasibility.ConditionallyFeasible;
}

/// <summary>
/// I/V-only TSV/CSV adapter. Every result and topology status comes from the
/// production engine. The Topology column is a mandatory explicit choice; there
/// is no automatic topology, family, location or range-policy column.
/// </summary>
public sealed class SignalConversionManualTestRowService
{
    public const int MaximumBatchRows=1_000;
    public const int InputColumnCount=33;
    public const int ResultColumnCount=16;
    public const int ColumnCount=InputColumnCount+ResultColumnCount;
    public const string Header="PointId\tName\tTopology\tInputMinA\tInputMaxA\tOutputAtInputMinV\tOutputAtInputMaxV\tVccV\tVeeV\tBandwidthHz\tAccuracyPct\tMinResolvedInputA\tPreserveLoadGround\tInputCapF\tFeedbackParasiticF\tOutputLoadOhm\tHighSideCommonModeV\tMaxBurdenV\tMaxShuntPowerW\tSeries\tDeviceParametersVerified\tOpAmpGBWHz\tOpAmpOutputCurrentA\tOpAmpBiasA\tOpAmpOffsetV\tOpAmpCommonModeMinV\tOpAmpCommonModeMaxV\tOpAmpVoltageNoiseVrtHz\tOpAmpCurrentNoiseArtHz\tPcbLeakageA\tSwitchLeakageA\tSwitchOnResistanceOhm\tSwitchParasiticF\tSuccess\tFeasibility\tSupportedTopologies\tTopologySupport\tMessage\tActualSlopeVPerA\tActualOffsetV\tMaxErrorPct\tBandwidthActualHz\tPowerW\tRangeCount\tComponentCount\tCircuitGraphCheck\tVerification\tConstraints\tWarnings";

    public IReadOnlyList<ParsedSignalConversionTestRow> ParseMany(string text)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(text);
        var lines=text.Replace("\r",string.Empty,StringComparison.Ordinal).Split('\n',StringSplitOptions.TrimEntries|StringSplitOptions.RemoveEmptyEntries)
            .Where(line=>!line.StartsWith("PointId",StringComparison.OrdinalIgnoreCase)).ToArray();
        if(lines.Length==0)throw new FormatException("No I/V test rows were found.");
        if(lines.Length>MaximumBatchRows)throw new FormatException($"A maximum of {MaximumBatchRows} rows can be run at once; received {lines.Length}.");
        var rows=new List<ParsedSignalConversionTestRow>(lines.Length);
        for(var index=0;index<lines.Length;index++)
        {
            try{rows.Add(Parse(lines[index]));}
            catch(Exception exception) when(exception is FormatException or ArgumentException){throw new FormatException($"Row {index+1}: {exception.Message}",exception);}
        }
        return rows;
    }

    public ParsedSignalConversionTestRow Parse(string line)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(line);var delimiter=line.Contains('\t')?'\t':',';
        var fields=line.Trim().Split(delimiter,StringSplitOptions.None).Select(value=>value.Trim()).ToArray();
        if(fields.Length is not (InputColumnCount or ColumnCount))throw new FormatException($"Expected {InputColumnCount} input fields or {ColumnCount} completed fields, but received {fields.Length}.");
        var input=fields.Take(InputColumnCount).ToArray();
        var request=new SignalConversionDesignRequest
        {
            RequestedTopology=EnumValue<SignalConversionTopology>(input[2],"Topology"),InputMinimum=Number(input[3],"InputMinA"),InputMaximum=Number(input[4],"InputMaxA"),
            OutputAtInputMinimum=Number(input[5],"OutputAtInputMinV"),OutputAtInputMaximum=Number(input[6],"OutputAtInputMaxV"),
            SupplyHighVoltage=Number(input[7],"VccV"),SupplyLowVoltage=Number(input[8],"VeeV"),TargetBandwidthHz=Number(input[9],"BandwidthHz"),
            TargetAccuracyPercent=Number(input[10],"AccuracyPct"),MinimumResolvedInputMagnitude=Number(input[11],"MinResolvedInputA"),
            MustPreserveLoadGround=Boolean(input[12],"PreserveLoadGround"),
            InputAndSensorCapacitanceFarad=Number(input[13],"InputCapF"),FeedbackParasiticCapacitanceFarad=Number(input[14],"FeedbackParasiticF"),
            OutputLoadResistanceOhm=Number(input[15],"OutputLoadOhm"),HighSideCommonModeVoltage=Number(input[16],"HighSideCommonModeV"),
            MaximumBurdenVoltage=Number(input[17],"MaxBurdenV"),MaximumShuntPowerWatt=Number(input[18],"MaxShuntPowerW"),
            PreferredSeries=EnumValue<SignalConversionPreferredSeries>(input[19],"Series"),DeviceParametersVerified=Boolean(input[20],"DeviceParametersVerified"),
            OpAmpGainBandwidthHz=Number(input[21],"OpAmpGBWHz"),OpAmpOutputCurrentAmpere=Number(input[22],"OpAmpOutputCurrentA"),
            OpAmpInputBiasCurrentAmpere=Number(input[23],"OpAmpBiasA"),OpAmpInputOffsetVoltage=Number(input[24],"OpAmpOffsetV"),
            OpAmpInputCommonModeMinimumVoltage=Number(input[25],"OpAmpCommonModeMinV"),OpAmpInputCommonModeMaximumVoltage=Number(input[26],"OpAmpCommonModeMaxV"),
            OpAmpVoltageNoiseVoltPerRootHz=Number(input[27],"OpAmpVoltageNoiseVrtHz"),OpAmpCurrentNoiseAmperePerRootHz=Number(input[28],"OpAmpCurrentNoiseArtHz"),
            PcbLeakageCurrentAmpere=Number(input[29],"PcbLeakageA"),AnalogSwitchLeakageAmpere=Number(input[30],"SwitchLeakageA"),
            AnalogSwitchOnResistanceOhm=Number(input[31],"SwitchOnResistanceOhm"),AnalogSwitchParasiticCapacitanceFarad=Number(input[32],"SwitchParasiticF")
        };
        return new(input,delimiter,request);
    }

    public IReadOnlyList<SignalConversionTopologyEvaluation> EvaluateTopologies(SignalConversionDesignRequest request,SignalConversionDesignEngine? engine=null)    {
        engine??=new SignalConversionDesignEngine();var evaluations=new List<SignalConversionTopologyEvaluation>(5);
        foreach(var topology in Enum.GetValues<SignalConversionTopology>())
        {
            var result=engine.Design(request with{RequestedTopology=topology});
            var candidate=result.Candidates.FirstOrDefault(item=>item.Topology==topology);
            evaluations.Add(new(topology,candidate?.Feasibility??CandidateFeasibility.Infeasible,candidate?.Constraints??["No candidate was produced."]));
        }
        return evaluations;
    }

    public string Complete(ParsedSignalConversionTestRow parsed,SignalConversionDesignResult result,IReadOnlyList<SignalConversionTopologyEvaluation>? evaluations=null)
    {
        var candidate=result.Candidates.FirstOrDefault(item=>item.Topology==parsed.Request.RequestedTopology);
        var graphCheck=candidate?.Verification.LastOrDefault(item=>item.Name.Contains("CircuitGraph",StringComparison.OrdinalIgnoreCase));
        evaluations??=EvaluateTopologies(parsed.Request);
        var supported=Join(evaluations.Where(item=>item.Supported).Select(item=>item.Topology.ToString()));
        var supportDetail=Join(evaluations.Select(item=>$"{item.Topology}={item.Feasibility}{(item.Reasons.Count==0?string.Empty:" ("+item.Reasons[0]+")")}"));
        var fields=new[]
        {
            result.Success?"1":"0",candidate?.Feasibility.ToString()??"NA",supported,supportDetail,Clean(result.Message),
            Value(candidate?.ActualTransferSlope),Value(candidate?.ActualTransferOffset),Value(candidate?.MaximumTransferErrorPercent),Value(candidate?.PredictedBandwidthHz),
            Value(candidate?.PredictedPowerWatt),candidate?.RangeCount.ToString(CultureInfo.InvariantCulture)??"0",candidate?.Components.Count.ToString(CultureInfo.InvariantCulture)??"0",
            graphCheck?.Outcome.ToString()??"NA",Join(candidate?.Verification.Select(item=>$"{item.Name}:{item.Outcome}")??[]),
            Join(candidate?.Constraints??[]),Join(candidate?.Warnings??[])
        };
        return string.Join(parsed.Delimiter,parsed.InputFields.Concat(fields));
    }

    public string CreateBuiltIn70PointText(bool includeHeader=true)
    {
        var rows=CreateBuiltIn70Requests().Select((item,index)=>Serialize(index+1,item.Name,item.Request));
        return (includeHeader?Header+Environment.NewLine:string.Empty)+string.Join(Environment.NewLine,rows);
    }

    public IReadOnlyList<(string Name,SignalConversionDesignRequest Request)> CreateBuiltIn70Requests()
    {
        var rows=new List<(string,SignalConversionDesignRequest)>();
        for(var i=0;i<15;i++)
        {
            var imin=(1+.04*i)*1e-6;var imax=(.45+.012*i)*1e-3;var rf=2_000+100*i;
            Add($"BasicTIA_{i+1:00}",Base(SignalConversionTopology.BasicTia,imin,imax,-rf*imin,-rf*imax,-5,5,1_000,2) with{OpAmpInputOffsetVoltage=1e-6,OpAmpInputBiasCurrentAmpere=1e-12,PcbLeakageCurrentAmpere=.1e-12});
        }
        for(var i=0;i<15;i++)
        {
            var imin=(8+.25*i)*1e-6;var imax=(.45+.01*i)*1e-3;var rf=2_500+75*i;var reference=3.5+.02*(i%5);
            Add($"BiasedTIA_{i+1:00}",Base(SignalConversionTopology.BiasedTia,imin,imax,reference-rf*imin,reference-rf*imax,0,5,1_000,2) with{OpAmpInputOffsetVoltage=1e-6,OpAmpInputBiasCurrentAmpere=1e-12,PcbLeakageCurrentAmpere=.1e-12});
        }
        for(var i=0;i<15;i++)Add($"MultiTIA_{i+1:00}",Base(SignalConversionTopology.MultiRangeTia,(.8+.04*i)*1e-6,(.5+.015*i)*1e-3,3.2,.2,0,5,50+5*i,5) with
        {MinimumResolvedInputMagnitude=(.8+.04*i)*1e-6,InputAndSensorCapacitanceFarad=5e-12,OpAmpInputBiasCurrentAmpere=.1e-12,PcbLeakageCurrentAmpere=.01e-12,AnalogSwitchLeakageAmpere=.01e-12,OpAmpInputOffsetVoltage=1e-6,OpAmpGainBandwidthHz=100e6});
        for(var i=0;i<15;i++)Add($"LowShunt_{i+1:00}",Base(SignalConversionTopology.LowSideShuntAmplifier,0,.45+.025*i,.5,3.8+.02*(i%5),0,5,5_000,2) with
        {OpAmpInputOffsetVoltage=2e-6,OpAmpVoltageNoiseVoltPerRootHz=2e-9});
        for(var i=0;i<10;i++)Add($"HighShunt_{i+1:00}",Base(SignalConversionTopology.HighSideShuntAmplifier,0,.4+.03*i,.5,4,0,12,5_000,2) with
        {MustPreserveLoadGround=true,HighSideCommonModeVoltage=4+.3*i,OpAmpInputCommonModeMaximumVoltage=12,OpAmpInputOffsetVoltage=2e-6,OpAmpVoltageNoiseVoltPerRootHz=2e-9});
        return rows;
        void Add(string name,SignalConversionDesignRequest request)=>rows.Add((name,request));
    }

    private static SignalConversionDesignRequest Base(SignalConversionTopology topology,double imin,double imax,double vAtMin,double vAtMax,double vee,double vcc,double bandwidth,double accuracy)=>new()
    {
        RequestedTopology=topology,InputMinimum=imin,InputMaximum=imax,OutputAtInputMinimum=vAtMin,OutputAtInputMaximum=vAtMax,
        SupplyLowVoltage=vee,SupplyHighVoltage=vcc,OpAmpInputCommonModeMinimumVoltage=vee,OpAmpInputCommonModeMaximumVoltage=vcc,
        TargetBandwidthHz=bandwidth,TargetAccuracyPercent=accuracy
    };

    /// <summary>Serializes one request into the 33-column batch input format.</summary>
    public string SerializeRow(int id,string name,SignalConversionDesignRequest request)=>Serialize(id,name,request);

    private static string Serialize(int id,string name,SignalConversionDesignRequest r)=>string.Join('\t',new[]
    {
        id.ToString(CultureInfo.InvariantCulture),name,r.RequestedTopology!.Value.ToString(),N(r.InputMinimum),N(r.InputMaximum),N(r.OutputAtInputMinimum),N(r.OutputAtInputMaximum),
        N(r.SupplyHighVoltage),N(r.SupplyLowVoltage),N(r.TargetBandwidthHz),N(r.TargetAccuracyPercent),N(r.MinimumResolvedInputMagnitude),
        r.MustPreserveLoadGround?"1":"0",N(r.InputAndSensorCapacitanceFarad),N(r.FeedbackParasiticCapacitanceFarad),
        N(r.OutputLoadResistanceOhm),N(r.HighSideCommonModeVoltage),N(r.MaximumBurdenVoltage),N(r.MaximumShuntPowerWatt),r.PreferredSeries.ToString(),r.DeviceParametersVerified?"1":"0",
        N(r.OpAmpGainBandwidthHz),N(r.OpAmpOutputCurrentAmpere),N(r.OpAmpInputBiasCurrentAmpere),N(r.OpAmpInputOffsetVoltage),N(r.OpAmpInputCommonModeMinimumVoltage),
        N(r.OpAmpInputCommonModeMaximumVoltage),N(r.OpAmpVoltageNoiseVoltPerRootHz),N(r.OpAmpCurrentNoiseAmperePerRootHz),N(r.PcbLeakageCurrentAmpere),N(r.AnalogSwitchLeakageAmpere),
        N(r.AnalogSwitchOnResistanceOhm),N(r.AnalogSwitchParasiticCapacitanceFarad)
    });
    private static string N(double value)=>value.ToString("G17",CultureInfo.InvariantCulture);
    private static double Number(string value,string name)=>double.TryParse(value,NumberStyles.Float,CultureInfo.InvariantCulture,out var result)?result:throw new FormatException($"{name} must be an invariant-culture number; received '{value}'.");
    private static bool Boolean(string value,string name)=>value.Trim().ToLowerInvariant() switch{"1" or "true" or "yes"=>true,"0" or "false" or "no"=>false,_=>throw new FormatException($"{name} must be 1/0 or true/false; received '{value}'.")};
    private static T EnumValue<T>(string value,string name) where T:struct,Enum=>Enum.TryParse<T>(value,true,out var result)?result:throw new FormatException($"{name} has unknown value '{value}'.");
    private static string Value(double? value)=>value is null||!double.IsFinite(value.Value)?"NA":value.Value.ToString("G12",CultureInfo.InvariantCulture);
    private static string Join(IEnumerable<string> values){var text=string.Join(" | ",values.Select(Clean).Where(value=>value.Length>0));return text.Length==0?"NA":text;}
    private static string Clean(string value)=>value.Replace('\t',' ').Replace('\r',' ').Replace('\n',' ').Replace(',',';').Trim();
}
